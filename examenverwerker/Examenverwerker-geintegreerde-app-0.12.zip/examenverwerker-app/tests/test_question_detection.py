"""Tests voor hoofdvraagherkenning en het opslaan van visuele correcties."""
import tempfile
import unittest
from pathlib import Path

import fitz
from fastapi.testclient import TestClient

from examenverwerker import main
from examenverwerker.storage import Store
from examenverwerker.question_detection import detect_question_starts, validate_review
from examenverwerker.question_fragments import generate_question_fragments, build_stitched_exam
from examenverwerker.question_analysis import analyse_questions, detect_options, detect_question_type, detect_max_points, validate_question_analysis


class QuestionDetectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        main.DATA = self.root
        main.STORE = Store(self.root)
        self.client = TestClient(main.app)

    def tearDown(self):
        self.temp.cleanup()

    def make_pdf(self):
        doc = fitz.open()
        page = doc.new_page()
        # Een vraagnummer op een eigen regel is een kandidaat. Een subnummer,
        # een getal midden in een zin en een paginavoet zijn dat nadrukkelijk niet.
        page.insert_text((60, 70), "1\nWat is de functie van dit orgaan?\n1a\nNoem twee kenmerken.\nDe temperatuur is 37 graden.", fontsize=11)
        page.insert_text((60, 130), "2. Beschrijf de bouw van het orgaan.", fontsize=11)
        page.insert_text((60, 800), "3", fontsize=8)
        data = doc.tobytes()
        doc.close()
        return data

    def test_detector_uses_only_standalone_main_question_lines(self):
        path = self.root / "sample.pdf"
        path.write_bytes(self.make_pdf())
        result = detect_question_starts(str(path))
        self.assertEqual(result["page_count"], 1)
        self.assertEqual([item["question_number"] for item in result["candidates"]], [1, 2])
        self.assertEqual(result["candidates"][0]["page_index"], 0)
        self.assertEqual(len(result["candidates"][0]["preview_bbox"]), 4)

    def test_detector_keeps_sequence_outliers_visible_instead_of_silently_dropping_them(self):
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text((60, 80), "11. Eerste vraag", fontsize=11)
        page.insert_text((60, 112), "6 kPa is de gemeten druk", fontsize=11)
        page.insert_text((60, 144), "1, 2 of 3 uitspraken zijn juist", fontsize=11)
        page.insert_text((60, 176), "12. Twaalfde vraag", fontsize=11)
        page.insert_text((60, 208), "1. Dit is geen nieuwe vraagreeks", fontsize=11)
        path = self.root / "false-numbers.pdf"
        path.write_bytes(doc.tobytes())
        doc.close()
        result = detect_question_starts(str(path))
        self.assertEqual([item["question_number"] for item in result["candidates"]], [11, 12, 1])
        self.assertTrue(result["candidates"][-1]["sequence_warning"])

    def test_page_alignment_is_calculated_independently_for_each_page(self):
        # Even en oneven pagina's kunnen door hun spiegelmarges een andere
        # linkerpositie voor de vraagnummerkolom hebben. Beide pagina's moeten
        # hun eigen uitlijning mogen gebruiken.
        doc = fitz.open()
        doc.new_page()
        doc.new_page()
        doc[0].insert_text((58, 80), "1. Eerste vraag", fontsize=11)
        doc[1].insert_text((104, 80), "2. Tweede vraag", fontsize=11)
        path = self.root / "alternating-margins.pdf"
        path.write_bytes(doc.tobytes())
        doc.close()

        result = detect_question_starts(str(path))
        self.assertEqual([(item["question_number"], item["page_index"])
                          for item in result["candidates"]], [(1, 0), (2, 1)])

    def test_page_result_exposes_pdf_words_for_reading_manual_number_box(self):
        path = self.root / "manual-number.pdf"
        path.write_bytes(self.make_pdf())
        result = detect_question_starts(str(path))
        words = result["pages"][0]["words"]
        self.assertTrue(any(word["text"] == "2." and len(word["bbox"]) == 4
                            for word in words))

    def test_review_validation_rejects_invalid_page_and_bbox(self):
        with self.assertRaises(ValueError):
            validate_review({"candidates":[{"id":"x","question_number":1,"page_index":2,"pdf_bbox":[1,1,2,2],"accepted":True}]}, 1)
        with self.assertRaises(ValueError):
            validate_review({"candidates":[{"id":"x","question_number":1,"page_index":0,"pdf_bbox":[2,2,1,1],"accepted":True}]}, 1)

    def test_api_returns_candidates_and_persists_review_as_pending(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        self.assertEqual(response.status_code, 200, response.text)
        exam_id = response.json()["exam_id"]
        confirmed = self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        self.assertEqual(confirmed.status_code, 200, confirmed.text)
        detected = self.client.get(f"/api/exams/{exam_id}/question-starts")
        self.assertEqual(detected.status_code, 200, detected.text)
        candidate = detected.json()["candidates"][0]
        saved = self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":[candidate]})
        self.assertEqual(saved.status_code, 200, saved.text)
        exam = self.client.get(f"/api/exams/{exam_id}").json()
        self.assertEqual(exam["steps"]["opgaven_starts"]["status"], "pending")
        self.assertEqual(exam["steps"]["opgaven_starts"]["evidence"]["accepted_count"], 1)

    def test_review_validation_rejects_coordinates_outside_page(self):
        review = {"candidates":[{"id":"manual-1","question_number":1,"page_index":0,
                                  "pdf_bbox":[10,10,2000,20],"accepted":True,"source":"manual"}]}
        with self.assertRaisesRegex(ValueError, "buiten de paginagrenzen"):
            validate_review(review, 1, [(595.0, 842.0)])

    def test_manual_candidate_is_restored_after_reload(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        detected = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        manual = {"id":"manual-test-1", "question_number":3, "page_index":0,
                  "text":"Handmatig toegevoegde vraagstart", "pdf_bbox":[60,200,90,218],
                  "preview_bbox":[81,270,121.5,294.3], "accepted":True, "source":"manual"}
        candidates = detected["candidates"] + [manual]
        saved = self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":candidates})
        self.assertEqual(saved.status_code, 200, saved.text)
        reloaded = self.client.get(f"/api/exams/{exam_id}/question-starts")
        self.assertEqual(reloaded.status_code, 200, reloaded.text)
        self.assertIn("manual-test-1", [item["id"] for item in reloaded.json()["candidates"]])

    def test_manually_corrected_question_number_survives_reload(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        detected = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        # Simuleer een docent die een automatisch fout herkend nummer corrigeert.
        corrected = [dict(item) for item in detected["candidates"]]
        corrected[1]["question_number"] = 7
        saved = self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":corrected})
        self.assertEqual(saved.status_code, 200, saved.text)

        reloaded = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        restored = next(item for item in reloaded["candidates"] if item["id"] == corrected[1]["id"])
        self.assertEqual(restored["question_number"], 7)

    def test_removed_automatic_candidate_stays_removed_after_reload(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        detected = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        removed = dict(detected["candidates"][0], accepted=False, removed=True)
        candidates = [removed, *detected["candidates"][1:]]
        self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":candidates})
        reloaded = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        self.assertNotIn(removed["id"], [item["id"] for page in reloaded["pages"] for item in page["candidates"]])

    def test_fragment_generator_splits_question_across_pages(self):
        document = fitz.open()
        first = document.new_page()
        first.insert_text((60, 80), "Vraag 1 begint hier")
        second = document.new_page()
        second.insert_text((60, 130), "Vraag 1 loopt hier verder")
        second.insert_text((60, 300), "Vraag 2 begint hier")
        pdf_path = self.root / "two-pages.pdf"
        document.save(pdf_path)
        document.close()
        starts = [
            {"id":"q1", "question_number":1, "page_index":0, "pdf_bbox":[60,70,90,85]},
            {"id":"q2", "question_number":2, "page_index":1, "pdf_bbox":[60,290,90,305]},
        ]
        result = generate_question_fragments(pdf_path, starts, self.root / "derived")
        self.assertEqual(result["question_count"], 2)
        self.assertEqual([segment["page_number"] for segment in result["questions"][0]["segments"]], [1,2])
        self.assertTrue((self.root / "derived" / result["questions"][0]["segments"][0]["filename"]).is_file())
        self.assertLess(result["questions"][0]["segments"][1]["pdf_clip"][3], 842)

    def test_fragment_step_cannot_complete_without_full_review(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        detected = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        saved = self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":detected["candidates"]})
        self.client.post(f"/api/exams/{exam_id}/steps/opgaven_starts/complete", json={"reviewed":True, "reviewed_all_pages":True})
        fragments = self.client.get(f"/api/exams/{exam_id}/question-fragments")
        self.assertEqual(fragments.status_code, 200, fragments.text)
        first_image_url = fragments.json()["questions"][0]["segments"][0]["url"]
        image_response = self.client.get(first_image_url)
        self.assertEqual(image_response.status_code, 200, image_response.text)
        self.assertEqual(image_response.headers.get("content-type"), "image/png")
        bypass = self.client.post(f"/api/exams/{exam_id}/steps/opgaven_fragments/complete", json={"reviewed":True})
        self.assertEqual(bypass.status_code, 422)
        numbers = [question["question_number"] for question in fragments.json()["questions"]]
        review = self.client.post(f"/api/exams/{exam_id}/question-fragments/review", json={
            "reviewed_question_numbers":numbers, "reviewed_all_questions":True
        })
        self.assertEqual(review.status_code, 200, review.text)
        self.assertTrue(review.json()["complete"])
        complete = self.client.post(f"/api/exams/{exam_id}/steps/opgaven_fragments/complete", json={"reviewed":True})
        self.assertEqual(complete.status_code, 200, complete.text)
        analysis = self.client.get(f"/api/exams/{exam_id}/question-analysis")
        self.assertEqual(analysis.status_code, 200, analysis.text)
        questions = analysis.json()["questions"]
        self.assertTrue(questions)
        bypass_analysis = self.client.post(f"/api/exams/{exam_id}/steps/opgaven_analyse/complete", json={"reviewed":True})
        self.assertEqual(bypass_analysis.status_code, 422)
        for question in questions:
            question["reviewed"] = True
        saved_analysis = self.client.post(f"/api/exams/{exam_id}/question-analysis/review", json={"questions":questions})
        self.assertEqual(saved_analysis.status_code, 200, saved_analysis.text)
        self.assertTrue(saved_analysis.json()["complete"])
        completed_analysis = self.client.post(f"/api/exams/{exam_id}/steps/opgaven_analyse/complete", json={"reviewed":True})
        self.assertEqual(completed_analysis.status_code, 200, completed_analysis.text)

    def test_reopen_question_starts_preserves_draft_and_invalidates_fragments(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        detected = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":detected["candidates"]})
        self.client.post(f"/api/exams/{exam_id}/steps/opgaven_starts/complete", json={"reviewed":True, "reviewed_all_pages":True})
        reopened = self.client.post(f"/api/exams/{exam_id}/steps/opgaven_starts/reopen")
        self.assertEqual(reopened.status_code, 200, reopened.text)
        exam = self.client.get(f"/api/exams/{exam_id}").json()
        self.assertEqual(exam["steps"]["opgaven_starts"]["status"], "pending")
        self.assertTrue(exam["steps"]["opgaven_starts"]["evidence"]["candidates"])

    def test_question_analysis_detects_options_closed_forms_and_explicit_points(self):
        text = "Kies het juiste antwoord.\nA. eerste antwoord\nB. tweede antwoord\nC. derde antwoord\nMaximumscore 2 punten"
        options = detect_options(text)
        self.assertEqual([item["letter"] for item in options], ["A", "B", "C"])
        self.assertEqual(detect_question_type(text, options)[0], "meerkeuze")
        self.assertEqual(detect_max_points(text)[0], 2)
        closed_type, _ = detect_question_type("Is de uitspraak juist/onjuist?", [])
        self.assertEqual(closed_type, "gesloten")
        mc_without_options, _ = detect_question_type("Kies het juiste antwoord bij de afbeelding.", [])
        self.assertEqual(mc_without_options, "meerkeuze")

    def test_question_analysis_validation_requires_every_question_reviewed(self):
        payload = {"questions":[
            {"question_number":1,"question_type":"meerkeuze","max_points":2,
             "options":[{"letter":"A","text":"optie"}],"reviewed":True},
            {"question_number":2,"question_type":"open","max_points":None,"options":[],"reviewed":False},
        ]}
        result = validate_question_analysis(payload, {1,2})
        self.assertFalse(result["reviewed_all_questions"])
        payload["questions"][1]["reviewed"] = True
        self.assertTrue(validate_question_analysis(payload, {1,2})["reviewed_all_questions"])
        with self.assertRaisesRegex(ValueError, "dubbel genummerde"):
            validate_question_analysis({"questions":[{"question_number":1,"question_type":"meerkeuze",                "max_points":2,"options":[{"letter":"A","text":"x"},{"letter":"A","text":"y"}],"reviewed":True}]}, {1})

    def test_question_start_review_is_reused_for_answer_sheet_and_marking_scheme(self):
        sample = self.make_pdf()
        response = self.client.post("/api/exams/import", files=[
            ("files", ("biologie-vwo-2026-tv2-o.pdf", sample, "application/pdf")),
            ("files", ("biologie-vwo-2026-tv2-u.pdf", sample, "application/pdf")),
            ("files", ("biologie-vwo-2026-tv2-c.pdf", sample, "application/pdf")),
        ])
        self.assertEqual(response.status_code, 200, response.text)
        exam_id = response.json()["exam_id"]
        confirmed = self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{
                "biologie-vwo-2026-tv2-o.pdf":"opgaven",
                "biologie-vwo-2026-tv2-u.pdf":"uitwerkbijlage",
                "biologie-vwo-2026-tv2-c.pdf":"correctievoorschrift",
            }
        })
        self.assertEqual(confirmed.status_code, 200, confirmed.text)
        for document_type, step_key in [("uitwerkbijlage", "uitwerk_starts"), ("correctievoorschrift", "cv_starts")]:
            detected = self.client.get(f"/api/exams/{exam_id}/document-question-starts/{document_type}")
            self.assertEqual(detected.status_code, 200, detected.text)
            candidates = detected.json()["candidates"]
            saved = self.client.post(f"/api/exams/{exam_id}/document-question-starts/{document_type}/review", json={"candidates":candidates})
            self.assertEqual(saved.status_code, 200, saved.text)
            completed = self.client.post(f"/api/exams/{exam_id}/steps/{step_key}/complete", json={"reviewed":True, "reviewed_all_pages":True})
            self.assertEqual(completed.status_code, 200, completed.text)
            fragments = self.client.get(f"/api/exams/{exam_id}/document-question-fragments/{document_type}")
            self.assertEqual(fragments.status_code, 200, fragments.text)
            self.assertEqual(fragments.json()["document_type"], document_type)
            first_fragment_url = fragments.json()["questions"][0]["segments"][0]["url"]
            fragment_image = self.client.get(first_fragment_url)
            self.assertEqual(fragment_image.status_code, 200, fragment_image.text)
            self.assertEqual(fragment_image.headers.get("content-type"), "image/png")
            reviewed_numbers = [question["question_number"] for question in fragments.json()["questions"]]
            saved_fragments = self.client.post(f"/api/exams/{exam_id}/document-question-fragments/{document_type}/review", json={
                "reviewed_question_numbers":reviewed_numbers, "reviewed_all_questions":True
            })
            self.assertEqual(saved_fragments.status_code, 200, saved_fragments.text)
            fragment_step = "uitwerk_fragments" if document_type == "uitwerkbijlage" else "cv_fragments"
            completed_fragments = self.client.post(f"/api/exams/{exam_id}/steps/{fragment_step}/complete", json={"reviewed":True})
            self.assertEqual(completed_fragments.status_code, 200, completed_fragments.text)

    def test_stitched_exam_skips_cover_and_returns_page_coordinate_map(self):
        # De lange werkafbeelding begint op pagina 2; pagina 1 is de omslag.
        # Beide inhoudspagina's moeten in documentvolgorde terug te vinden zijn.
        doc = fitz.open()
        for label in ("OMSLAG", "INHOUD PAGINA TWEE", "INHOUD PAGINA DRIE"):
            page = doc.new_page()
            page.insert_text((70, 100), label, fontsize=14)
        source = self.root / "stitched-source.pdf"
        target = self.root / "exam-long.png"
        source.write_bytes(doc.tobytes())
        doc.close()
        metadata = build_stitched_exam(source, target, render_scale=0.8)
        self.assertTrue(target.is_file())
        self.assertEqual([page["page_number"] for page in metadata["pages"]], [2, 3])
        self.assertEqual(metadata["height"], metadata["pages"][0]["stitched_height"] +
                         metadata["pages"][1]["stitched_height"] + metadata["page_gap"])
        self.assertLess(metadata["pages"][0]["top"], metadata["pages"][1]["top"])

    def test_cv_fragments_remove_repeated_marginal_lines_and_stitch_pages(self):
        document = fitz.open()
        first = document.new_page()
        first.insert_text((60, 30), "Correctievoorschrift biologie", fontsize=8)
        first.insert_text((60, 90), "1")
        first.insert_text((60, 130), "Een antwoord wordt goed gerekend wanneer...")
        first.insert_text((60, 810), "1", fontsize=8)
        second = document.new_page()
        second.insert_text((60, 30), "Correctievoorschrift biologie", fontsize=8)
        second.insert_text((60, 100), "Vervolg van vraag 1")
        second.insert_text((60, 300), "2")
        second.insert_text((60, 810), "2", fontsize=8)
        pdf_path = self.root / "cv.pdf"
        document.save(pdf_path)
        document.close()
        starts = [
            {"id":"cv-q1", "question_number":1, "page_index":0, "pdf_bbox":[60,80,80,95]},
            {"id":"cv-q2", "question_number":2, "page_index":1, "pdf_bbox":[60,290,80,305]},
        ]
        result = generate_question_fragments(pdf_path, starts, self.root / "cv-derived", document_type="correctievoorschrift")
        question_one = result["questions"][0]
        self.assertTrue(question_one["stitched"])
        self.assertEqual(len(question_one["source_segments"]), 2)
        self.assertEqual(len(question_one["segments"]), 1)
        stitched_path = self.root / "cv-derived" / question_one["segments"][0]["filename"]
        self.assertTrue(stitched_path.is_file())
        from PIL import Image
        source_sizes = []
        for segment in question_one["source_segments"]:
            with Image.open(self.root / "cv-derived" / segment["filename"]) as source_image:
                source_sizes.append(source_image.size)
        with Image.open(stitched_path) as stitched:
            self.assertEqual(stitched.width, max(size[0] for size in source_sizes))
            self.assertEqual(stitched.height, sum(size[1] for size in source_sizes) + 24)



    def test_detector_recognises_score_prefix_before_question_number(self):
        document = fitz.open()
        page = document.new_page()
        page.insert_text((60, 100), "1p 1 Geef een combinatie van ouders en nakomeling.", fontsize=11)
        page.insert_text((60, 180), "2p 2 Uit het fenotype blijkt dat het gen.", fontsize=11)
        path = self.root / "score-prefix.pdf"
        document.save(path)
        document.close()
        result = detect_question_starts(str(path))
        self.assertEqual([item["question_number"] for item in result["candidates"]], [1, 2])

    def test_fragment_generator_applies_manual_boundary_overrides(self):
        document = fitz.open()
        page = document.new_page()
        page.insert_text((60, 120), "Question content starts here")
        page.insert_text((60, 220), "Question content ends here")
        pdf_path = self.root / "boundaries.pdf"
        document.save(pdf_path)
        document.close()
        starts = [{"id":"q1", "question_number":1, "page_index":0, "pdf_bbox":[60,110,90,125]}]
        result = generate_question_fragments(pdf_path, starts, self.root / "boundary-derived",
                                             boundary_overrides={1:{"start_y":150,"end_y":260}})
        clip = result["questions"][0]["segments"][0]["pdf_clip"]
        self.assertEqual(clip[1], 150)
        self.assertEqual(clip[3], 260)

    def test_last_cv_question_stops_before_administrative_pages(self):
        document = fitz.open()
        first = document.new_page()
        first.insert_text((60, 100), "1")
        first.insert_text((60, 140), "Answer criteria for the final question")
        second = document.new_page()
        second.insert_text((60, 100), "Continuation of the answer criteria")
        third = document.new_page()
        third.insert_text((60, 100), "5 Aanleveren scores")
        pdf_path = self.root / "cv-ending.pdf"
        document.save(pdf_path)
        document.close()
        result = generate_question_fragments(pdf_path,
            [{"id":"q1", "question_number":1, "page_index":0, "pdf_bbox":[60,90,80,105]}],
            self.root / "cv-derived", document_type="correctievoorschrift")
        self.assertEqual(result["questions"][0]["last_page"], 2)

    def test_duplicate_accepted_question_numbers_block_start_completion(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        result = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        first = result["candidates"][0]
        duplicate = dict(first, id="duplicate-question-one")
        self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":[first, duplicate]})
        completed = self.client.post(f"/api/exams/{exam_id}/steps/opgaven_starts/complete", json={"reviewed":True,"reviewed_all_pages":True})
        self.assertEqual(completed.status_code, 422)
        self.assertIn("dubbele hoofdvraagstarts", completed.text)

    def test_fragment_boundary_override_is_saved_and_used_by_api(self):
        response = self.client.post("/api/exams/import", files=[("files", ("biologie-vwo-2026-tv2-o.pdf", self.make_pdf(), "application/pdf"))])
        exam_id = response.json()["exam_id"]
        self.client.post(f"/api/exams/{exam_id}/metadata/confirm", json={
            "subject":"biologie", "level":"vwo", "year":2026, "period":2,
            "document_types":{"biologie-vwo-2026-tv2-o.pdf":"opgaven"}
        })
        starts = self.client.get(f"/api/exams/{exam_id}/question-starts").json()
        self.client.post(f"/api/exams/{exam_id}/question-starts/review", json={"candidates":starts["candidates"]})
        self.client.post(f"/api/exams/{exam_id}/steps/opgaven_starts/complete", json={"reviewed":True,"reviewed_all_pages":True})
        fragments = self.client.get(f"/api/exams/{exam_id}/document-question-fragments/opgaven").json()
        question = fragments["questions"][0]
        saved = self.client.post(f"/api/exams/{exam_id}/document-question-fragments/opgaven/review", json={
            "reviewed_question_numbers":[question["question_number"]],"reviewed_all_questions":True,
            "boundary_overrides":[{"question_number":question["question_number"],"start_y":150,"end_y":300}]
        })
        self.assertEqual(saved.status_code, 200, saved.text)
        regenerated = self.client.get(f"/api/exams/{exam_id}/document-question-fragments/opgaven").json()
        self.assertEqual(regenerated["questions"][0]["segments"][0]["pdf_clip"][1], 150)
        self.assertEqual(regenerated["questions"][0]["segments"][0]["pdf_clip"][3], 300)


if __name__ == "__main__":
    unittest.main()
