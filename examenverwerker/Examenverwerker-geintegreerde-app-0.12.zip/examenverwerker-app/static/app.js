/*
 * Front-end voor de geïntegreerde examenwerkruimte.
 * Alle blijvende gegevens worden via de API opgeslagen; deze JavaScript-code
 * bewaart alleen de tijdelijke selectie van het huidige scherm. Daardoor
 * verdwijnen metadata of voortgang niet wanneer de browser wordt vernieuwd.
 */
const state = { examId: null, exam: null, workflow: [] };
const $ = (selector) => document.querySelector(selector);

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = body.detail;
    throw new Error(typeof detail === 'string' ? detail : (detail?.message || JSON.stringify(detail) || 'Er is iets misgegaan.'));
  }
  return body;
}

function showLibrary() {
  $('#libraryView').hidden = false;
  $('#workspaceView').hidden = true;
  $('#backLibrary').hidden = true;
  state.examId = null;
  state.exam = null;
  loadLibrary();
}

async function loadLibrary() {
  const exams = await api('/api/exams');
  $('#examCount').textContent = `${exams.length} ${exams.length === 1 ? 'examen' : 'examens'}`;
  $('#examList').innerHTML = exams.length ? exams.map(exam => `
    <article class="exam-row"><div class="doc-icon">PDF</div><div><strong>${escapeHtml(exam.title)}</strong><p>${exam.published ? 'Gepubliceerd in examenbibliotheek' : (exam.confirmed ? 'Metadata bevestigd · nog niet gepubliceerd' : 'Metadata nog te bevestigen')} · geïmporteerd ${new Date(exam.created_at + 'Z').toLocaleDateString('nl-NL')}</p></div><button class="quiet" data-open="${exam.id}">Open werkruimte →</button></article>
  `).join('') : '<p class="muted">Er zijn nog geen examens geïmporteerd.</p>';
  document.querySelectorAll('[data-open]').forEach(button => button.addEventListener('click', () => openWorkspace(button.dataset.open)));
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

$('#importForm').addEventListener('submit', async event => {
  event.preventDefault();
  $('#importError').textContent = '';
  const files = $('#pdfFiles').files;
  if (!files.length) return;
  const form = new FormData();
  [...files].forEach(file => form.append('files', file));
  const button = event.submitter;
  button.disabled = true;
  button.textContent = 'PDF-bestanden controleren…';
  try {
    const result = await api('/api/exams/import', { method: 'POST', body: form });
    $('#pdfFiles').value = '';
    await openWorkspace(result.exam_id);
  } catch (error) {
    $('#importError').textContent = error.message;
  } finally {
    button.disabled = false;
    button.textContent = 'Importeren en verwerken';
  }
});

$('#backLibrary').addEventListener('click', showLibrary);

async function openWorkspace(examId) {
  state.examId = examId;
  state.exam = await api(`/api/exams/${examId}`);
  state.workflow = await api('/api/workflow');
  $('#libraryView').hidden = true;
  $('#workspaceView').hidden = false;
  $('#backLibrary').hidden = false;
  renderWorkspace();
}

function renderWorkspace() {
  const exam = state.exam;
  $('#examTitle').textContent = exam.title;
  const metadata = exam.metadata;
  $('#examMeta').textContent = exam.confirmed
    ? `${metadata.subject} · ${metadata.level} · ${metadata.year} · tijdvak ${metadata.period}`
    : `${exam.documents.length} documenten · metadata nog niet bevestigd`;
  const completed = Object.keys(exam.steps).filter(key => exam.steps[key].status === 'complete');
  const next = state.workflow.find(step => !completed.includes(step.key));
  $('#overallStatus').textContent = completed.includes('eindcontrole') ? 'Controle afgerond' : 'In verwerking';
  $('#stepList').innerHTML = state.workflow.map((step, index) => {
    const done = completed.includes(step.key);
    const current = next?.key === step.key;
    return `<div class="step-item ${done ? 'complete' : ''} ${current ? 'current' : ''}"><span class="step-number">${done ? '✓' : index + 1}</span><div><strong>${escapeHtml(step.title)}</strong><small>${done ? 'Afgerond' : current ? 'Volgende stap' : 'Nog niet uitgevoerd'}</small></div></div>`;
  }).join('');
  if (!exam.confirmed) renderMetadataStage();
  else if (next?.key === 'opgaven_starts') renderQuestionStartsStage('opgaven_starts', 'opgaven', 'FASE 2 · OPGAVENDOCUMENT', 'Vraagstarts opgaven');
  else if (next?.key === 'opgaven_fragments') renderQuestionFragmentsStage('opgaven_fragments', 'opgaven', 'opgaven_starts', 'FASE 2 · OPGAVENDOCUMENT', 'Vraagfragmenten opgaven');
  else if (next?.key === 'opgaven_analyse') renderQuestionAnalysisStage();
  else if (next?.key === 'uitwerk_starts' && !examHasDocumentType('uitwerkbijlage')) renderSkipWorkbookStage();
  else if (next?.key === 'uitwerk_starts') renderQuestionStartsStage('uitwerk_starts', 'uitwerkbijlage', 'FASE 3 · UITWERKBIJLAGE', 'Vraagstarts uitwerkbijlage');
  else if (next?.key === 'uitwerk_fragments') renderQuestionFragmentsStage('uitwerk_fragments', 'uitwerkbijlage', 'uitwerk_starts', 'FASE 3 · UITWERKBIJLAGE', 'Fragmenten uitwerkbijlage');
  else if (next?.key === 'cv_starts') renderQuestionStartsStage('cv_starts', 'correctievoorschrift', 'FASE 4 · CORRECTIEVOORSCHRIFT', 'Vraagstarts correctievoorschrift');
  else if (next?.key === 'cv_fragments') renderQuestionFragmentsStage('cv_fragments', 'correctievoorschrift', 'cv_starts', 'FASE 4 · CORRECTIEVOORSCHRIFT', 'Correctievoorschriftfragmenten');
  else if (next?.key === 'cv_aanvulling') renderCvSupplementStage();
  else if (next?.key === 'antwoorden') renderAnswersStage();
  else if (next?.key === 'relaties') renderRelationsStage();
  else if (next?.key === 'snippets') renderSnippetsStage();
  else if (next?.key === 'eindcontrole') renderFinalReviewStage();
  else if (next?.key === 'publicatie') renderPublicationStage();
  else renderStageOverview(next, completed);
}

function renderMetadataStage() {
  const exam = state.exam;
  const first = exam.documents[0].metadata;
  const common = (key) => exam.documents.map(doc => doc.metadata[key]).find(value => value !== '' && value != null) ?? '';
  const types = {opgaven:'Opgaven',uitwerkbijlage:'Uitwerkbijlage',correctievoorschrift:'Correctievoorschrift',aanvulling_correctievoorschrift:'Aanvulling correctievoorschrift'};
  $('#stagePanel').innerHTML = `
    <p class="eyebrow">FASE 1 · IMPORT EN DOCUMENTHERKENNING</p><h2>Documenteigenschappen bevestigen</h2>
    <p class="lead">Controleer de voorstellen en bevestig de eigenschappen in één keer. Daarna wordt deze stap niet opnieuw gevraagd.</p>
    <div class="document-list">${exam.documents.map(doc => `<div class="document-card"><strong>${escapeHtml(doc.filename)}</strong><small>${doc.page_count} pagina's · ${doc.sha256.slice(0,12)}…</small><button class="quiet" data-preview="${doc.id}">Eerste pagina bekijken</button></div>`).join('')}</div>
    <form id="metadataForm" class="metadata-form">
      <div class="fields">
        <div class="field"><label for="subject">Vak</label><input id="subject" value="${escapeHtml(common('subject') || 'biologie')}" required></div>
        <div class="field"><label for="level">Niveau</label><input id="level" value="${escapeHtml(common('level'))}" placeholder="vwo" required></div>
        <div class="field"><label for="year">Jaar</label><input id="year" type="number" min="2000" max="2099" value="${escapeHtml(common('year'))}" required></div>
        <div class="field"><label for="period">Tijdvak</label><input id="period" type="number" min="1" max="3" value="${escapeHtml(common('period'))}" required></div>
      </div>
      <h3>Documenttypen</h3><div class="type-list">${exam.documents.map(doc => `<div class="type-row"><span>${escapeHtml(doc.filename)}</span><select data-type-for="${escapeHtml(doc.filename)}">${Object.entries(types).map(([value,label]) => `<option value="${value}" ${doc.metadata.document_type === value ? 'selected' : ''}>${label}</option>`).join('')}</select></div>`).join('')}</div>
      <div class="notice">De originele PDF's blijven ongewijzigd. De eerste pagina wordt alleen gebruikt om de metadata te herkennen en als visueel voorbeeld te tonen.</div>
      <button class="primary" type="submit">Metadata bevestigen en doorgaan</button><p id="metadataError" class="form-error" role="alert"></p>
    </form><div id="pagePreview"></div>`;
  document.querySelectorAll('[data-preview]').forEach(button => button.addEventListener('click', () => showPreview(button.dataset.preview)));
  $('#metadataForm').addEventListener('submit', confirmMetadata);
}

async function showPreview(documentId) {
  const doc = state.exam.documents.find(item => String(item.id) === String(documentId));
  $('#pagePreview').innerHTML = `<div class="preview-wrap"><p class="muted">Eerste pagina · ${escapeHtml(doc.filename)}</p><img alt="Eerste pagina van ${escapeHtml(doc.filename)}" src="/api/exams/${state.examId}/documents/${documentId}/preview/0"></div>`;
}

async function confirmMetadata(event) {
  event.preventDefault();
  const payload = {
    subject: $('#subject').value.trim(), level: $('#level').value.trim(),
    year: Number($('#year').value), period: Number($('#period').value),
    document_types: Object.fromEntries([...document.querySelectorAll('[data-type-for]')].map(select => [select.dataset.typeFor, select.value]))
  };
  try {
    await api(`/api/exams/${state.examId}/metadata/confirm`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    await openWorkspace(state.examId);
  } catch (error) { $('#metadataError').textContent = error.message; }
}


/* De aanvulling wordt nooit automatisch op het bestaande CV toegepast.
   Iedere pagina krijgt een expliciete keuze, zodat een onduidelijke wijziging
   niet ongemerkt een bestaande beoordelingsregel kan overschrijven. */

function examHasDocumentType(documentType) {
  return state.exam.documents.some(doc => state.exam.metadata.document_types?.[doc.filename] === documentType);
}

async function renderSkipWorkbookStage() {
  const panel=$('#stagePanel');
  panel.innerHTML=`<p class="eyebrow">FASE 3 · UITWERKBIJLAGE</p><h2>Geen uitwerkbijlage aanwezig</h2><p class="lead">Voor dit examen is geen afzonderlijke uitwerkbijlage geïmporteerd. Deze twee stappen worden als niet van toepassing gemarkeerd; de overige verwerking gaat gewoon door.</p><button class="primary" id="skipWorkbook">Geen uitwerkbijlage bevestigen</button><p id="workbookMessage" class="form-error" role="status"></p>`;
  $('#skipWorkbook').addEventListener('click',async()=>{try{await api(`/api/exams/${state.examId}/skip-optional-workbook`,{method:'POST'});await openWorkspace(state.examId);}catch(error){$('#workbookMessage').textContent=error.message;}});
}

async function renderCvSupplementStage() {
  const panel = $('#stagePanel');
  panel.innerHTML = '<p class="muted">Aanvulling op het correctievoorschrift controleren…</p>';
  try {
    const result = await api(`/api/exams/${state.examId}/cv-supplement`);
    if (result.not_required) {
      panel.innerHTML = `<p class="eyebrow">FASE 5 · AANVULLING CORRECTIEVOORSCHRIFT</p><h2>Geen aanvulling aanwezig</h2><p class="lead">Er is geen document als aanvulling op het correctievoorschrift geïmporteerd. Het oorspronkelijke CV blijft ongewijzigd.</p><button class="primary" id="confirmNoSupplement">Geen aanvulling bevestigen en doorgaan</button><p id="supplementMessage" class="form-error" role="status"></p>`;
      $('#confirmNoSupplement').addEventListener('click', async () => {
        try {
          await api(`/api/exams/${state.examId}/steps/cv_aanvulling/complete`, {
            method:'POST', headers:{'Content-Type':'application/json'},
            body:JSON.stringify({reviewed:true, not_required:true})
          });
          await openWorkspace(state.examId);
        } catch (error) { $('#supplementMessage').textContent = error.message; }
      });
      return;
    }
    const doc = result.document;
    panel.innerHTML = `<p class="eyebrow">FASE 5 · AANVULLING CORRECTIEVOORSCHRIFT</p><h2>Aanvulling per pagina beoordelen</h2><p class="lead">Het oorspronkelijke correctievoorschrift blijft intact. Kies per pagina of inhoud wordt toegevoegd, vervangen, genegeerd of handmatig beoordeeld. De app voert geen inhoudelijke vervanging automatisch uit.</p><div class="notice">${result.page_count} pagina's · ${escapeHtml(doc.filename)} · elke pagina moet afzonderlijk worden bekeken.</div>
      ${result.items.map(item => `<article class="analysis-card" data-supplement-page="${item.page_number}"><h3>Pagina ${item.page_number}${item.question_numbers.length ? ` · vraag ${item.question_numbers.join(', ')}` : ''}</h3><img class="fragment-image" loading="lazy" alt="Pagina ${item.page_number} van de CV-aanvulling" src="/api/exams/${state.examId}/documents/${doc.id}/preview/${item.page_index}"><p class="analysis-reason">${escapeHtml(item.reason)}</p><label>Verwerking<select data-supplement-action="${item.page_number}"><option value="toevoegen" ${item.action==='toevoegen'?'selected':''}>Toevoegen</option><option value="vervangen" ${item.action==='vervangen'?'selected':''}>Vervangen</option><option value="handmatig" ${item.action==='handmatig'?'selected':''}>Handmatig beoordelen</option><option value="negeren" ${item.action==='negeren'?'selected':''}>Geen inhoudelijke wijziging</option></select></label><label>Betrokken vraagnummers (komma's scheiden)<input type="text" data-supplement-questions="${item.page_number}" value="${item.question_numbers.join(', ')}" placeholder="bijvoorbeeld 12, 22"></label><details class="analysis-text"><summary>Tekst uit deze pagina</summary><pre>${escapeHtml(item.text || 'Geen selecteerbare tekstlaag; beoordeel de pagina-afbeelding.')}</pre></details><label class="review-warning"><input type="checkbox" data-supplement-reviewed="${item.page_number}" ${item.reviewed?'checked':''}> Ik heb deze pagina en de voorgestelde verwerking gecontroleerd.</label></article>`).join('')}
      <div class="review-actions"><button class="primary" id="saveSupplement" type="button">Controle opslaan</button><button class="primary" id="completeSupplement" type="button" disabled>Aanvulling beoordelen en doorgaan</button></div><p id="supplementMessage" class="form-error" role="status"></p>`;
    const cards = [...document.querySelectorAll('[data-supplement-page]')];
    const checks = () => [...document.querySelectorAll('[data-supplement-reviewed]')];
    const refresh = () => { $('#completeSupplement').disabled = checks().some(input => !input.checked); };
    checks().forEach(input => input.addEventListener('change', refresh)); refresh();
    const collect = () => cards.map(card => {
      const page = Number(card.dataset.supplementPage);
      const item = result.items.find(entry => entry.page_number === page);
      const numbersText=card.querySelector(`[data-supplement-questions="${page}"]`).value;
      const numbers=numbersText.split(',').map(value=>value.trim()).filter(Boolean).map(Number);
      return {page_number:page, action:card.querySelector(`[data-supplement-action="${page}"]`).value,
        question_numbers:numbers, reviewed:card.querySelector(`[data-supplement-reviewed="${page}"]`).checked};
    });
    const save = () => api(`/api/exams/${state.examId}/cv-supplement/review`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:collect()})});
    $('#saveSupplement').addEventListener('click', async () => { try { const r=await save(); $('#supplementMessage').textContent=`${r.reviewed_count} van ${r.page_count} pagina's gecontroleerd. Concept opgeslagen.`; } catch(error) { $('#supplementMessage').textContent=error.message; } });
    $('#completeSupplement').addEventListener('click', async () => { try { const r=await save(); if(!r.complete) throw new Error('Controleer eerst alle pagina’s.'); await api(`/api/exams/${state.examId}/steps/cv_aanvulling/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed:true,reviewed_all_pages:true})}); await openWorkspace(state.examId); } catch(error) { $('#supplementMessage').textContent=error.message; } });
  } catch (error) { panel.innerHTML = `<h2>Aanvulling correctievoorschrift</h2><p class="form-error">${escapeHtml(error.message)}</p>`; }
}

/* Antwoordvoorstellen komen uit de bijbehorende CV-fragmenten. De gebruiker
   ziet altijd de bronafbeelding, kan de tekst corrigeren en moet elk antwoord
   afzonderlijk afvinken. De tekstherkenning is dus nooit een eindbeslissing. */
async function renderAnswersStage() {
  const panel = $('#stagePanel');
  panel.innerHTML = '<p class="muted">Antwoorden uit het correctievoorschrift analyseren…</p>';
  try {
    const result = await api(`/api/exams/${state.examId}/answers`);
    panel.innerHTML = `<p class="eyebrow">FASE 6 · ANTWOORDEN HERKENNEN</p><h2>Antwoorden controleren</h2><p class="lead">Per vraag staat het bijbehorende fragment uit het correctievoorschrift. Herkende meerkeuzeletters en gesloten antwoorden zijn voorstellen. Controleer de bronafbeelding en corrigeer de antwoordtekst waar nodig.</p><div class="notice">${result.question_count} CV-fragmenten · lage zekerheid betekent dat de tekst handmatig moet worden nagekeken.</div>
      ${result.questions.map(q => `<article class="analysis-card" data-answer-card="${q.question_number}"><div class="card-heading"><h3>Vraag ${q.question_number}</h3><span class="status-pill">${escapeHtml(q.confidence)} zekerheid</span></div><p class="analysis-reason">${escapeHtml(q.reason)} · Maximumscore CV: ${q.cv_max_points ?? 'onbekend'} · Opgaven: ${q.opgaven_max_points ?? 'onbekend'}${q.points_match===false?' · SCORES VERSCHILLEN':''}</p>${q.segments.map(seg=>`<img class="fragment-image" loading="lazy" alt="Correctievoorschrift vraag ${q.question_number}" src="${escapeHtml(seg.url)}">`).join('')}${(q.supplement_pages||[]).map(page=>`<div class="notice">CV-aanvulling · pagina ${page.page_number} · ${escapeHtml(page.action)}</div><img class="fragment-image" loading="lazy" alt="CV-aanvulling bij vraag ${q.question_number}" src="${escapeHtml(page.url)}">`).join('')}<div class="analysis-fields"><label>Antwoordvorm<select data-answer-kind="${q.question_number}"><option value="meerkeuze" ${q.answer_kind==='meerkeuze'?'selected':''}>Meerkeuze</option><option value="gesloten" ${q.answer_kind==='gesloten'?'selected':''}>Gesloten antwoord</option><option value="open" ${q.answer_kind==='open'?'selected':''}>Open antwoord / beoordelingscriteria</option><option value="handmatig" ${q.answer_kind==='handmatig'?'selected':''}>Handmatig bepalen</option></select></label></div><label>Antwoord of beoordelingscriteria<textarea rows="4" data-answer-text="${q.question_number}">${escapeHtml(q.answer_text)}</textarea></label><label class="review-warning"><input type="checkbox" data-answer-reviewed="${q.question_number}" ${q.reviewed?'checked':''}> Ik heb het antwoord van vraag ${q.question_number} aan de hand van het CV-fragment gecontroleerd.</label></article>`).join('')}
      <div class="review-actions"><button class="primary" id="saveAnswers" type="button">Controle opslaan</button><button class="primary" id="completeAnswers" type="button" disabled>Antwoorden goedkeuren en doorgaan</button></div><p id="answersMessage" class="form-error" role="status"></p>`;
    const cards=[...document.querySelectorAll('[data-answer-card]')];
    const checks=()=>[...document.querySelectorAll('[data-answer-reviewed]')];
    const refresh=()=>{$('#completeAnswers').disabled=checks().some(input=>!input.checked);};
    checks().forEach(input=>input.addEventListener('change',refresh)); refresh();
    const collect=()=>cards.map(card=>{const n=Number(card.dataset.answerCard);return {question_number:n,answer_kind:card.querySelector(`[data-answer-kind="${n}"]`).value,answer_text:card.querySelector(`[data-answer-text="${n}"]`).value,reviewed:card.querySelector(`[data-answer-reviewed="${n}"]`).checked};});
    const save=()=>api(`/api/exams/${state.examId}/answers/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({questions:collect()})});
    $('#saveAnswers').addEventListener('click',async()=>{try{const r=await save();$('#answersMessage').textContent=`${r.reviewed_count} van ${result.question_count} antwoorden gecontroleerd. Concept opgeslagen.`;}catch(error){$('#answersMessage').textContent=error.message;}});
    $('#completeAnswers').addEventListener('click',async()=>{try{const r=await save();if(!r.complete)throw new Error('Controleer eerst alle antwoorden.');await api(`/api/exams/${state.examId}/steps/antwoorden/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed:true,reviewed_all_questions:true})});await openWorkspace(state.examId);}catch(error){$('#answersMessage').textContent=error.message;}});
  } catch(error) { panel.innerHTML=`<h2>Antwoorden herkennen</h2><p class="form-error">${escapeHtml(error.message)}</p>`; }
}

/* De relatiescherm controleert niet alleen aantallen, maar toont expliciet
   welke vragen een CV-fragment hebben en welke vragen ook in de uitwerkbijlage
   voorkomen. De uitwerkbijlage hoeft niet alle examenvragen te bevatten. */
async function renderRelationsStage() {
  const panel=$('#stagePanel');
  panel.innerHTML='<p class="muted">Document- en vraagkoppelingen controleren…</p>';
  try {
    const result=await api(`/api/exams/${state.examId}/relations`);
    panel.innerHTML=`<p class="eyebrow">FASE 7 · DOCUMENTKOPPELINGEN</p><h2>Vragen tussen documenten koppelen</h2><p class="lead">Controleer of elke opgave bij het juiste correctievoorschrift hoort. De uitwerkbijlage bevat soms slechts enkele invulvragen; afwezigheid daar is dus niet automatisch een fout.</p><div class="notice">${result.question_count} opgaven · ${result.questions.filter(q=>q.has_cv).length} CV-koppelingen · ${result.uitwerk_questions.length} vragen in de uitwerkbijlage</div>${result.missing_cv.length?`<p class="form-error">Geen CV-fragment gevonden bij: ${result.missing_cv.join(', ')}</p>`:''}${result.extra_cv.length?`<p class="notice">CV-vragen zonder corresponderende opgave: ${result.extra_cv.join(', ')}</p>`:''}
      ${result.questions.map(q=>`<article class="analysis-card" data-relation-card="${q.question_number}"><div class="card-heading"><h3>Vraag ${q.question_number}</h3><span class="status-pill">${q.has_cv?'CV gekoppeld':'CV ontbreekt'}</span></div><div class="relation-grid"><span>Opgaven: aanwezig</span><span>CV: ${q.has_cv?'aanwezig':'ontbreekt'}</span><span>Uitwerkbijlage: ${q.has_uitwerkbijlage?'aanwezig':'niet van toepassing'}</span><span>Maximumscore opgave: ${q.max_points??'nog niet bepaald'}</span><span>Maximumscore CV: ${q.cv_max_points??'nog niet bepaald'}</span><span>Scorecontrole: ${q.points_match===true?'gelijk':q.points_match===false?'verschil':'nog niet vergelijkbaar'}</span></div><label>Opmerking / correctie<textarea rows="2" data-relation-note="${q.question_number}"></textarea></label><label class="review-warning"><input type="checkbox" data-relation-reviewed="${q.question_number}" ${q.reviewed?'checked':''}> Ik heb de koppeling van vraag ${q.question_number} gecontroleerd.</label></article>`).join('')}
      <div class="review-actions"><button class="primary" id="saveRelations" type="button">Koppelingen opslaan</button><button class="primary" id="completeRelations" type="button" disabled>Koppelingen goedkeuren en doorgaan</button></div><p id="relationsMessage" class="form-error" role="status"></p>`;
    const cards=[...document.querySelectorAll('[data-relation-card]')];
    const checks=()=>[...document.querySelectorAll('[data-relation-reviewed]')];
    const refresh=()=>{$('#completeRelations').disabled=checks().some(input=>!input.checked)||result.missing_cv.length>0;};
    checks().forEach(input=>input.addEventListener('change',refresh)); refresh();
    const collect=()=>cards.map(card=>{const n=Number(card.dataset.relationCard);return {question_number:n,reviewed:card.querySelector(`[data-relation-reviewed="${n}"]`).checked,note:card.querySelector(`[data-relation-note="${n}"]`).value};});
    const save=()=>api(`/api/exams/${state.examId}/relations/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({questions:collect()})});
    $('#saveRelations').addEventListener('click',async()=>{try{const r=await save();$('#relationsMessage').textContent=`${r.reviewed_count} van ${result.question_count} koppelingen gecontroleerd.`;}catch(error){$('#relationsMessage').textContent=error.message;}});
    $('#completeRelations').addEventListener('click',async()=>{try{const r=await save();if(!r.complete)throw new Error('Controleer eerst alle koppelingen.');await api(`/api/exams/${state.examId}/steps/relaties/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed:true,reviewed_all_questions:true})});await openWorkspace(state.examId);}catch(error){$('#relationsMessage').textContent=error.message;}});
  } catch(error) { panel.innerHTML=`<h2>Documentkoppelingen</h2><p class="form-error">${escapeHtml(error.message)}</p>`; }
}


/* De snippetfase maakt contextkandidaten los van de vraagfragmenten. Een
   contextbereik wordt alleen als voorstel ingevuld; de docent controleert en
   corrigeert de reeks vragen waarop de context van toepassing is. */
async function renderSnippetsStage() {
  const panel=$('#stagePanel');
  panel.innerHTML='<p class="muted">Contexten en definitieve snippets voorbereiden…</p>';
  try {
    const result=await api(`/api/exams/${state.examId}/snippets`);
    const contextCards=result.contexts.map(context=>`<article class="analysis-card" data-context-card="${escapeHtml(context.id)}"><div class="card-heading"><h3>Context · pagina ${context.page_number}</h3><span class="muted">Voorstel: vraag ${context.suggested_from_question}–${context.to_question}</span></div><img class="fragment-image" loading="lazy" src="${escapeHtml(context.url)}" alt="Contextfragment op pagina ${context.page_number}"><p class="analysis-reason">${escapeHtml(context.label)}</p><div class="analysis-fields"><label>Vanaf vraag<input type="number" min="1" max="60" data-context-from="${escapeHtml(context.id)}" value="${context.from_question}"></label><label>Tot en met vraag<input type="number" min="1" max="60" data-context-to="${escapeHtml(context.id)}" value="${context.to_question}"></label></div><details class="analysis-text"><summary>Tekstlaag (hulpmiddel)</summary><pre>${escapeHtml(context.extracted_text)}</pre></details><label class="review-warning"><input type="checkbox" data-context-reviewed="${escapeHtml(context.id)}" ${context.reviewed?'checked':''}> Ik heb deze context en het vraagbereik gecontroleerd.</label></article>`).join('');
    const questionCards=result.opgaven.questions.map(q=>`<article class="analysis-card" data-snippet-question="${q.question_number}"><h3>Vraag ${q.question_number}</h3><div class="fragment-images">${q.segments.map(seg=>`<figure><figcaption>Pagina ${seg.page_number}</figcaption><img loading="lazy" src="${escapeHtml(seg.url)}" alt="Definitief vraagfragment ${q.question_number}"></figure>`).join('')}</div><label class="review-warning"><input type="checkbox" data-snippet-reviewed="${q.question_number}" ${q.reviewed?'checked':''}> Ik heb het definitieve vraagfragment gecontroleerd.</label></article>`).join('');
    const workbookCards=result.uitwerkbijlage.questions.map(q=>`<article class="analysis-card"><h3>Uitwerkbijlage · vraag ${q.question_number}</h3>${q.segments.map(seg=>`<img class="fragment-image" loading="lazy" src="${escapeHtml(seg.url)}" alt="Uitwerkbijlagevraag ${q.question_number}">`).join('')}<label class="review-warning"><input type="checkbox" data-snippet-uitwerk="${q.question_number}" ${q.reviewed?'checked':''}> Ik heb dit fragment gecontroleerd.</label></article>`).join('');
    const cvCards=result.correctievoorschrift.questions.map(q=>`<article class="analysis-card"><h3>Correctievoorschrift · vraag ${q.question_number}</h3>${q.segments.map(seg=>`<img class="fragment-image" loading="lazy" src="${escapeHtml(seg.url)}" alt="CV-fragment ${q.question_number}">`).join('')}<label class="review-warning"><input type="checkbox" data-snippet-cv="${q.question_number}" ${q.reviewed?'checked':''}> Ik heb dit CV-fragment gecontroleerd.</label></article>`).join('');
    panel.innerHTML=`<p class="eyebrow">FASE 8 · DEFINITIEVE SNIPPETS</p><h2>Contexten en snippets controleren</h2><p class="lead">De vraag-, uitwerkbijlage- en CV-fragmenten zijn uit de oorspronkelijke PDF's opgebouwd. Contexten worden afzonderlijk voorgesteld, zodat één context aan een reeks vragen gekoppeld kan worden.</p><div class="notice">${result.question_count} vragen · ${result.context_count} contextvoorstellen · ${result.uitwerkbijlage.question_count} uitwerkbijlagefragmenten · ${result.correctievoorschrift.question_count} CV-fragmenten.</div><h3>Contexten</h3>${contextCards||'<p class="muted">Geen contextvoorstellen op basis van de tekstlaag. Controleer de oorspronkelijke opgaven visueel en bevestig hieronder of er geen afzonderlijke contexten zijn.</p><label class="review-warning"><input type="checkbox" id="confirmNoContexts"> Ik heb gecontroleerd dat er geen afzonderlijke contextfragmenten gekoppeld hoeven te worden.</label>'}<h3>Vraagfragmenten</h3>${questionCards}<h3>Uitwerkbijlagefragmenten</h3>${workbookCards||'<p class="muted">Geen uitwerkbijlagefragmenten van toepassing.</p>'}<h3>Correctievoorschriftfragmenten</h3>${cvCards}<div class="review-actions"><button class="primary" id="saveSnippets">Snippetcontrole opslaan</button><button class="primary" id="completeSnippets" disabled>Snippets goedkeuren en doorgaan</button></div><p id="snippetsMessage" class="form-error" role="status"></p>`;
    const contextChecks=()=>[...document.querySelectorAll('[data-context-reviewed]')];
    const questionChecks=()=>[...document.querySelectorAll('[data-snippet-reviewed]')];
    const workbookChecks=()=>[...document.querySelectorAll('[data-snippet-uitwerk]')];
    const cvChecks=()=>[...document.querySelectorAll('[data-snippet-cv]')];
    const noContextConfirmed=()=>!result.contexts.length && $('#confirmNoContexts')?.checked;
    const refresh=()=>{$('#completeSnippets').disabled=contextChecks().some(x=>!x.checked)||questionChecks().some(x=>!x.checked)||workbookChecks().some(x=>!x.checked)||cvChecks().some(x=>!x.checked)||(!result.contexts.length&&!noContextConfirmed());};
    [...contextChecks(),...questionChecks(),...workbookChecks(),...cvChecks()].forEach(x=>x.addEventListener('change',refresh));
    $('#confirmNoContexts')?.addEventListener('change',refresh); refresh();
    const collect=()=>({contexts:result.contexts.map(c=>({id:c.id,from_question:Number(document.querySelector(`[data-context-from="${c.id}"]`).value),to_question:Number(document.querySelector(`[data-context-to="${c.id}"]`).value),reviewed:document.querySelector(`[data-context-reviewed="${c.id}"]`).checked})),reviewed_question_numbers:questionChecks().filter(x=>x.checked).map(x=>Number(x.dataset.snippetReviewed)),reviewed_uitwerk_numbers:workbookChecks().filter(x=>x.checked).map(x=>Number(x.dataset.snippetUitwerk)),reviewed_cv_numbers:cvChecks().filter(x=>x.checked).map(x=>Number(x.dataset.snippetCv)),confirmed_no_contexts:noContextConfirmed()});
    const save=()=>api(`/api/exams/${state.examId}/snippets/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collect())});
    $('#saveSnippets').addEventListener('click',async()=>{try{const r=await save();$('#snippetsMessage').textContent=`${r.reviewed_count} vragen en ${r.reviewed_all_contexts?result.context_count:contextChecks().filter(x=>x.checked).length} contexten gecontroleerd.`;}catch(error){$('#snippetsMessage').textContent=error.message;}});
    $('#completeSnippets').addEventListener('click',async()=>{try{const r=await save();if(!r.complete)throw new Error('Controleer eerst alle contexten en vraagfragmenten.');await api(`/api/exams/${state.examId}/steps/snippets/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed:true,reviewed_all_questions:true,reviewed_all_contexts:true})});await openWorkspace(state.examId);}catch(error){$('#snippetsMessage').textContent=error.message;}});
  } catch(error) { panel.innerHTML=`<h2>Definitieve snippets</h2><p class="form-error">${escapeHtml(error.message)}</p>`; }
}

/* De integrale eindcontrole toont alle bronnen in één vraagkaart. Problemen
   worden niet verborgen: ontbrekende koppelingen en afwijkende scores blijven
   zichtbaar en vragen een toelichting voordat het examen kan worden afgerond. */
async function renderFinalReviewStage() {
  const panel=$('#stagePanel');
  panel.innerHTML='<p class="muted">Integrale eindcontrole samenstellen…</p>';
  try {
    const result=await api(`/api/exams/${state.examId}/final-review`);
    panel.innerHTML=`<p class="eyebrow">FASE 9 · INTEGRALE EINDCONTROLE</p><h2>Iedere vraag in samenhang controleren</h2><p class="lead">Controleer per vraag de context, opgave, eventuele uitwerkbijlage, correctievoorschrift, antwoord en punten. Bij een verschil tussen de maximumscore in opgave en CV moet de oplossing worden toegelicht.</p><div class="notice">${result.question_count} vragen · controleer de volledige visuele samenhang vóór publicatie.</div>
      ${result.questions.map(q=>`<article class="analysis-card final-review-card" data-final-card="${q.question_number}"><div class="card-heading"><h3>Vraag ${q.question_number}</h3><span class="status-pill">${q.points_match===false?'Scoreverschil':q.correctievoorschrift.length?'CV gekoppeld':'CV ontbreekt'}</span></div><h4>Gekoppelde context</h4>${q.context.length?q.context.map(c=>`<figure><figcaption>Context · pagina ${c.page_number} · vragen ${c.from_question}–${c.to_question}</figcaption><img class="fragment-image" loading="lazy" src="${escapeHtml(c.url)}" alt="Context bij vraag ${q.question_number}"></figure>`).join(''):'<p class="muted">Geen context gekoppeld.</p>'}<h4>Opgave</h4>${q.opgaven.map(seg=>`<figure><figcaption>Pagina ${seg.page_number}</figcaption><img class="fragment-image" loading="lazy" src="${escapeHtml(seg.url)}" alt="Opgave ${q.question_number}"></figure>`).join('')}<h4>Uitwerkbijlage</h4>${q.uitwerkbijlage.length?q.uitwerkbijlage.map(seg=>`<img class="fragment-image" loading="lazy" src="${escapeHtml(seg.url)}" alt="Uitwerkbijlage ${q.question_number}">`).join(''):'<p class="muted">Geen bijbehorend onderdeel in de uitwerkbijlage.</p>'}<h4>Correctievoorschrift</h4>${q.correctievoorschrift.length?q.correctievoorschrift.map(seg=>`<img class="fragment-image" loading="lazy" src="${escapeHtml(seg.url)}" alt="Correctievoorschrift ${q.question_number}">`).join(''):'<p class="form-error">Geen CV-fragment gekoppeld.</p>'}${(q.supplement_pages||[]).map(page=>`<p class="analysis-reason">Aanvulling · pagina ${page.page_number} · ${escapeHtml(page.action)}${page.action==='vervangen'?' (vervangt het oorspronkelijke antwoordvoorstel)':''}</p><img class="fragment-image" loading="lazy" src="${escapeHtml(page.url)}" alt="Aanvulling correctievoorschrift bij vraag ${q.question_number}">`).join('')}${q.options?.length?`<h4>Herkende antwoordopties</h4><ul>${q.options.map(option=>`<li><strong>${escapeHtml(option.letter)}.</strong> ${escapeHtml(option.text)}</li>`).join('')}</ul>`:''}<div class="relation-grid"><span>Vraagtype: ${escapeHtml(q.question_type)}</span><span>Maximumscore opgave: ${q.max_points??'onbekend'}</span><span>Maximumscore CV: ${q.cv_max_points??'onbekend'}</span><span>Antwoordvorm: ${escapeHtml(q.answer_kind)}</span></div><details><summary>Antwoord / beoordelingscriteria</summary><pre>${escapeHtml(q.answer_text)}</pre></details>${q.points_match===false?'<p class="form-error">De maximumscores komen niet overeen. Leg vast hoe dit verschil is gecontroleerd.</p>':''}<label>Toelichting bij afwijking / herstel<textarea rows="2" data-final-note="${q.question_number}">${escapeHtml(q.resolution_note)}</textarea></label><label class="review-warning"><input type="checkbox" data-final-reviewed="${q.question_number}" ${q.reviewed?'checked':''}> Ik heb vraag ${q.question_number} in samenhang gecontroleerd.</label><div class="review-actions"><button class="quiet" type="button" data-repair="opgaven_fragments">Opgavefragment herstellen</button><button class="quiet" type="button" data-repair="opgaven_analyse">Vraagtype / punten / opties</button>${examHasDocumentType('uitwerkbijlage')?'<button class="quiet" type="button" data-repair="uitwerk_fragments">Uitwerkfragment herstellen</button>':''}<button class="quiet" type="button" data-repair="cv_fragments">CV-fragment herstellen</button><button class="quiet" type="button" data-repair="cv_aanvulling">CV-aanvulling aanpassen</button><button class="quiet" type="button" data-repair="antwoorden">Antwoord aanpassen</button><button class="quiet" type="button" data-repair="relaties">Koppeling herstellen</button></div></article>`).join('')}
      <div class="review-actions"><button class="primary" id="saveFinalReview">Eindcontrole opslaan</button><button class="primary" id="completeFinalReview" disabled>Eindcontrole afronden</button></div><p id="finalReviewMessage" class="form-error" role="status"></p>`;
    const cards=[...document.querySelectorAll('[data-final-card]')];
    const checks=()=>[...document.querySelectorAll('[data-final-reviewed]')];
    const refresh=()=>{$('#completeFinalReview').disabled=checks().some(x=>!x.checked)||result.questions.some(q=>q.points_match===false&&!document.querySelector(`[data-final-note="${q.question_number}"]`).value.trim());};
    checks().forEach(x=>x.addEventListener('change',refresh));
    document.querySelectorAll('[data-final-note]').forEach(x=>x.addEventListener('input',refresh)); refresh();
    const collect=()=>cards.map(card=>{const n=Number(card.dataset.finalCard);return {question_number:n,reviewed:card.querySelector(`[data-final-reviewed="${n}"]`).checked,resolution_note:card.querySelector(`[data-final-note="${n}"]`).value};});
    const save=()=>api(`/api/exams/${state.examId}/final-review/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({questions:collect()})});
    $('#saveFinalReview').addEventListener('click',async()=>{try{const r=await save();$('#finalReviewMessage').textContent=`${r.reviewed_count} van ${result.question_count} vragen gecontroleerd.`;}catch(error){$('#finalReviewMessage').textContent=error.message;}});
    $('#completeFinalReview').addEventListener('click',async()=>{try{const r=await save();if(!r.complete)throw new Error('Controleer eerst alle vragen.');await api(`/api/exams/${state.examId}/steps/eindcontrole/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed:true,reviewed_all_questions:true})});await openWorkspace(state.examId);}catch(error){$('#finalReviewMessage').textContent=error.message;}});
    document.querySelectorAll('[data-repair]').forEach(button=>button.addEventListener('click',async()=>{try{await api(`/api/exams/${state.examId}/steps/${button.dataset.repair}/reopen`,{method:'POST'});await openWorkspace(state.examId);}catch(error){$('#finalReviewMessage').textContent=error.message;}}));
  } catch(error) { panel.innerHTML=`<h2>Integrale eindcontrole</h2><p class="form-error">${escapeHtml(error.message)}</p>`; }
}

async function renderPublicationStage() {
  const panel=$('#stagePanel');
  panel.innerHTML=`<p class="eyebrow">FASE 10 · PUBLICATIE</p><h2>Examen publiceren</h2><p class="lead">Alle verwerkingsstappen en de integrale eindcontrole zijn afgerond. Publiceer het examen nu in de examenbibliotheek.</p><div class="notice">Na publicatie wordt het examen in de bibliotheek als gepubliceerd gemarkeerd. De oorspronkelijke PDF's en alle afgeleide fragmenten blijven bewaard.</div><button class="primary" id="publishExam">Publiceren in examenbibliotheek</button><p id="publishMessage" class="form-error" role="status"></p>`;
  $('#publishExam').addEventListener('click',async()=>{try{await api(`/api/exams/${state.examId}/publish`,{method:'POST'});await openWorkspace(state.examId);}catch(error){$('#publishMessage').textContent=error.message;}});
}

function renderStageOverview(next, completed) {
  const exam = state.exam;
  const nextStep = next || state.workflow[state.workflow.length - 1];
  if (!next && exam.published) {
    $('#stagePanel').innerHTML = `<p class="eyebrow">EXAMENBIBLIOTHEEK</p><h2>Examen gepubliceerd</h2><p class="lead">Alle verwerkingsstappen zijn afgerond en het examen is gepubliceerd.</p><button class="primary" id="returnLibrary">Terug naar examenbibliotheek</button>`;
    $('#returnLibrary').addEventListener('click', showLibrary);
    return;
  }
  const docs = exam.documents.map(doc => `<div class="document-card"><strong>${escapeHtml(doc.filename)}</strong><small>${doc.page_count} pagina's · ${doc.metadata.document_type || 'documenttype bevestigd'}</small><button class="quiet" data-preview="${doc.id}">PDF bekijken</button></div>`).join('');
  $('#stagePanel').innerHTML = `
    <p class="eyebrow">EXAMENWERKRUIMTE</p><h2>${escapeHtml(nextStep.title)}</h2>
    <p class="lead">${escapeHtml(nextStep.description)}</p>
    <div class="notice">De centrale werkruimte en persistente workflow zijn actief. De gespecialiseerde bewerkingsschermen worden stapsgewijs in deze omgeving geïntegreerd. Een stap kan niet worden overgeslagen: de server controleert de voorgangers en vereist controlebewijs.</div>
    <h3>Bronbestanden</h3>${docs}
    <h3>Voortgang</h3><p>${completed.length} van ${state.workflow.length} workflowstappen afgerond.</p>
    <div class="locked-note">De inhoudelijke bewerkingsinterface voor deze stap is nog in ontwikkeling. Er wordt geen stap als afgerond gemarkeerd zolang de bijbehorende visuele controle en opslag nog niet beschikbaar zijn.</div>`;
  document.querySelectorAll('[data-preview]').forEach(button => button.addEventListener('click', () => showPreview(button.dataset.preview)));
}

loadLibrary().catch(error => { $('#examList').textContent = error.message; });


/* De vraagstartreview is de eerste echte inhoudelijke werkstap in de nieuwe
   geïntegreerde applicatie. De PDF blijft de bron; de overlays zijn alleen
   een reviewlaag. Menselijke beslissingen worden als concept in SQLite
   opgeslagen en pas na een expliciete afrondactie workflowbewijs. */
async function renderQuestionStartsStage(stepKey, documentType, stageLabel, stageTitle, existingResult = null) {
  const panel = $('#stagePanel');
  panel.innerHTML = '<p class="muted">Vraagstarts analyseren…</p>';
  try {
    // Bij een handmatige wijziging gebruiken we het reeds geladen model.
    // Daardoor blijven alle nog niet opgeslagen beslissingen behouden.
    const result = existingResult || await api(`/api/exams/${state.examId}/document-question-starts/${documentType}`);
    state.questionStartReview = result;

    const renderCandidate = (item) => `
      <label class="candidate-row">
        <input type="checkbox" data-candidate="${escapeHtml(item.id)}" ${item.accepted ? 'checked' : ''}>
        <span><strong>Vraag ${item.question_number}</strong><small>${escapeHtml(item.text)} · positie ${Math.round(item.pdf_bbox[1])} pt${item.source === 'manual' ? ' · handmatig' : ''}${item.sequence_warning ? ' · nummer wijkt af van de volgorde; controleer' : ''}</small></span>
        <input aria-label="Vraagnummer" type="number" min="1" max="60" value="${item.question_number}" data-number="${escapeHtml(item.id)}" style="width:5rem">
        <select aria-label="Verplaats naar pagina" data-move="${escapeHtml(item.id)}">
          ${result.pages.map(page => `<option value="${page.page_index}" ${page.page_index === item.page_index ? 'selected' : ''}>P. ${page.page_index + 1}</option>`).join('')}
        </select>
        <button class="quiet small" type="button" data-reposition="${escapeHtml(item.id)}">Positie</button>
        <button class="quiet small" type="button" data-remove="${escapeHtml(item.id)}" aria-label="Vraagstart verwijderen">Verwijderen</button>
      </label>`;

    const renderPage = (page) => {
      const candidates = page.candidates.map(renderCandidate).join('');
      const rects = page.candidates.map(item => `<rect data-overlay="${escapeHtml(item.id)}" x="${item.preview_bbox[0]}" y="${item.preview_bbox[1]}" width="${item.preview_bbox[2]-item.preview_bbox[0]}" height="${Math.max(16,item.preview_bbox[3]-item.preview_bbox[1])}" />`).join('');
      return `<article class="question-page" data-page-card="${page.page_index}">
        <h4>Pagina ${page.page_index + 1} <span class="muted">· ${page.candidates.length} voorstellen</span></h4>
        <div class="page-canvas" data-page-canvas="${page.page_index}">
          <img src="/api/exams/${state.examId}/documents/${result.document.id}/preview/${page.page_index}" alt="Oorspronkelijke PDF-pagina ${page.page_index+1}">
          <svg viewBox="0 0 ${page.render_width} ${page.render_height}" preserveAspectRatio="none">${rects}</svg>
        </div>
        <div class="review-actions"><button class="quiet" type="button" data-add-manual="${page.page_index}">Vraagstart toevoegen op deze pagina</button></div>
        <div class="candidate-list" data-candidate-list="${page.page_index}">${candidates || '<p class="muted">Geen vraagstarts voorgesteld op deze pagina.</p>'}</div>
      </article>`;
    };

    const renderAll = () => {
      panel.innerHTML = `
        <p class="eyebrow">${stageLabel}</p>
        <h2>${escapeHtml(stageTitle)}</h2>
        <p class="lead">Controleer de markeringen op de oorspronkelijke pagina's. Je kunt starts toevoegen door op de juiste plek op een pagina te klikken, ze verwijderen of naar een andere pagina verplaatsen. De PDF blijft de bron.</p>
        <div class="notice"><strong>${result.candidates.filter(item => !item.removed).length} kandidaten</strong> in ${result.page_count} pagina's van ${escapeHtml(result.document.filename)}. Controleer ook pagina's waarop geen kandidaat is gevonden.</div>
        <div class="review-actions"><button class="quiet" id="acceptAllStarts" type="button">Alle voorstellen accepteren</button><button class="quiet" id="rejectAllStarts" type="button">Alle voorstellen afwijzen</button></div>
        ${result.pages.map(renderPage).join('')}
        <label class="review-warning"><input type="checkbox" id="allPagesReviewed"> Ik heb alle pagina's van dit document visueel gecontroleerd, ook de pagina's zonder voorstellen.</label>
        <div class="review-actions"><button class="primary" id="saveStartReview" type="button">Review opslaan</button><button class="primary" id="completeStartReview" type="button" disabled>Vraagstarts goedkeuren en doorgaan</button></div>
        <p id="startReviewMessage" class="form-error" role="status"></p>`;

      const candidateById = new Map(result.candidates.map(item => [item.id, item]));
      const syncControls = () => {
        document.querySelectorAll('[data-candidate]').forEach(input => {
          const item = candidateById.get(input.dataset.candidate);
          if (item) item.accepted = input.checked;
        });
        document.querySelectorAll('[data-number]').forEach(input => {
          const item = candidateById.get(input.dataset.number);
          const value = Number(input.value);
          if (item && Number.isInteger(value) && value >= 1 && value <= 60) item.question_number = value;
        });
      };
      const saveReview = async () => {
        syncControls();
        return api(`/api/exams/${state.examId}/document-question-starts/${documentType}/review`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({candidates:result.candidates})
        });
      };

      $('#acceptAllStarts').addEventListener('click', () => document.querySelectorAll('[data-candidate]').forEach(input => input.checked = true));
      $('#rejectAllStarts').addEventListener('click', () => document.querySelectorAll('[data-candidate]').forEach(input => input.checked = false));
      $('#allPagesReviewed').addEventListener('change', event => { $('#completeStartReview').disabled = !event.target.checked; });

      // Handmatig plaatsen gebruikt de zichtbare afbeelding als meetvlak en
      // rekent de klik terug naar PDF-punten. De server controleert daarna
      // opnieuw of de rechthoek binnen de werkelijke pagina valt.
      document.querySelectorAll('[data-add-manual]').forEach(button => button.addEventListener('click', () => {
        const pageIndex = Number(button.dataset.addManual);
        const canvas = document.querySelector(`[data-page-canvas="${pageIndex}"]`);
        const image = canvas.querySelector('img');
        button.textContent = 'Klik nu op de positie van de vraagstart…';
        button.disabled = true;
        canvas.classList.add('placing-question-start');
        const place = event => {
          const bounds = image.getBoundingClientRect();
          const page = result.pages[pageIndex];
          const x = Math.max(0, Math.min(page.width - 1, (event.clientX - bounds.left) / bounds.width * page.width));
          const y = Math.max(0, Math.min(page.height - 1, (event.clientY - bounds.top) / bounds.height * page.height));
          // Sla eerst alle op dat moment zichtbare wijzigingen op in de
          // JavaScript-objecten. Zonder deze stap bevat result.candidates nog
          // de oude nummers en zou een latere handmatige toevoeging die oude
          // waarde opnieuw kunnen terugzetten.
          syncControls();

          // Maak een ruim genoeg zoekvak rond de klik. De docent klikt op het
          // gedrukte vraagnummer; de detector zoekt vervolgens het exacte
          // numerieke PDF-woord dat dit vak raakt. Zo komt het nummer uit de
          // bronpagina en niet uit een automatisch gekozen vrije nummerreeks.
          const searchBox = [Math.max(0, x - 12), Math.max(0, y - 8),
            Math.min(page.width, x + 24), Math.min(page.height, y + 12)];
          const numberWord = (page.words || []).find(word => {
            const [wx0, wy0, wx1, wy1] = word.bbox;
            const overlaps = wx1 >= searchBox[0] && wx0 <= searchBox[2] &&
              wy1 >= searchBox[1] && wy0 <= searchBox[3];
            return overlaps && /^\d{1,2}[.)]?$/.test(word.text);
          });
          const numberMatch = numberWord ? numberWord.text.match(/\d{1,2}/) : null;
          let number = numberMatch ? Number(numberMatch[0]) : NaN;

          // Als de PDF geen selecteerbare tekstlaag heeft, blijft handmatig
          // invoeren mogelijk. We vragen dan expliciet om het nummer; nooit
          // stilzwijgend een foutief, zelfgekozen volgnummer gebruiken.
          if (!Number.isInteger(number) || number < 1 || number > 60) {
            const entered = window.prompt('Het vraagnummer kon niet uit de PDF-tekst worden gelezen. Vul het nummer in dat in het geplaatste vakje staat:');
            if (entered === null) return;
            number = Number(entered.trim());
          }
          if (!Number.isInteger(number) || number < 1 || number > 60) {
            $('#startReviewMessage').textContent = 'Gebruik een vraagnummer van 1 tot en met 60.';
            return;
          }

          // Gebruik bij voorkeur de exacte tekstbbox als positie. Als het
          // nummer uit meerdere losse PDF-elementen bestaat, blijft het
          // klikvak als veilige geometrische terugval beschikbaar.
          const bbox = numberWord ? [...numberWord.bbox] : searchBox;
          const candidate = {
            id: `manual-${crypto.randomUUID()}`, question_number:number, page_index:pageIndex,
            text:numberWord ? numberWord.text : 'Handmatig toegevoegde vraagstart', pdf_bbox:bbox,
            preview_bbox:[Number((bbox[0] * page.scale_x).toFixed(2)), Number((bbox[1] * page.scale_y).toFixed(2)),
              Number((bbox[2] * page.scale_x).toFixed(2)), Number((bbox[3] * page.scale_y).toFixed(2))],
            font_size:0, accepted:true, source:'manual', duplicate_number:false
          };
          result.candidates.push(candidate);
          page.candidates.push(candidate);
          page.candidate_count = page.candidates.length;
          renderAll();
        };
        canvas.addEventListener('click', place, {once:true});
      }));

      // Verplaatsen behoudt de relatieve positie op de pagina. Daardoor komt
      // de vraagstart op dezelfde visuele hoogte/kolom op de doelpagina terecht.
      document.querySelectorAll('[data-move]').forEach(select => select.addEventListener('change', () => {
        syncControls();
        const item = candidateById.get(select.dataset.move);
        const targetIndex = Number(select.value);
        if (!item || targetIndex === item.page_index) return;
        const oldPage = result.pages[item.page_index];
        const newPage = result.pages[targetIndex];
        const [x0,y0,x1,y1] = item.pdf_bbox;
        const relX = x0 / oldPage.width;
        const relY = y0 / oldPage.height;
        const boxW = (x1-x0) / oldPage.width;
        const boxH = (y1-y0) / oldPage.height;
        item.page_index = targetIndex;
        item.pdf_bbox = [relX*newPage.width, relY*newPage.height,
          Math.min(newPage.width, (relX+boxW)*newPage.width),
          Math.min(newPage.height, (relY+boxH)*newPage.height)];
        item.preview_bbox = [Number((item.pdf_bbox[0]*newPage.scale_x).toFixed(2)),
          Number((item.pdf_bbox[1]*newPage.scale_y).toFixed(2)),
          Number((item.pdf_bbox[2]*newPage.scale_x).toFixed(2)),
          Number((item.pdf_bbox[3]*newPage.scale_y).toFixed(2))];
        oldPage.candidates = oldPage.candidates.filter(candidate => candidate.id !== item.id);
        newPage.candidates.push(item);
        oldPage.candidate_count = oldPage.candidates.length;
        newPage.candidate_count = newPage.candidates.length;
        renderAll();
      }));

      // Een bestaande vraagstart kan ook exact opnieuw worden geplaatst.
      // De klik wordt omgerekend naar PDF-punten; daarmee verschuift later
      // automatisch de grens tussen dit fragment en de voorgaande vraag.
      document.querySelectorAll('[data-reposition]').forEach(button => button.addEventListener('click', () => {
        syncControls();
        const item = candidateById.get(button.dataset.reposition);
        if (!item) return;
        const targetPage = item.page_index;
        const canvas = document.querySelector(`[data-page-canvas="${targetPage}"]`);
        const image = canvas.querySelector('img');
        button.textContent = 'Klik nieuwe positie…';
        button.disabled = true;
        canvas.classList.add('placing-question-start');
        canvas.addEventListener('click', event => {
          const bounds = image.getBoundingClientRect();
          const page = result.pages[targetPage];
          const x = Math.max(0, Math.min(page.width - 1, (event.clientX - bounds.left) / bounds.width * page.width));
          const y = Math.max(0, Math.min(page.height - 1, (event.clientY - bounds.top) / bounds.height * page.height));
          const width = Math.max(8, item.pdf_bbox[2] - item.pdf_bbox[0]);
          const height = Math.max(8, item.pdf_bbox[3] - item.pdf_bbox[1]);
          item.pdf_bbox = [Math.max(0, x - 2), Math.max(0, y - 3),
            Math.min(page.width, x + width - 2), Math.min(page.height, y + height - 3)];
          item.preview_bbox = [Number((item.pdf_bbox[0] * page.scale_x).toFixed(2)),
            Number((item.pdf_bbox[1] * page.scale_y).toFixed(2)),
            Number((item.pdf_bbox[2] * page.scale_x).toFixed(2)),
            Number((item.pdf_bbox[3] * page.scale_y).toFixed(2))];
          renderAll();
        }, {once:true});
      }));

      // Verwijderen verwijdert alleen de kandidaat uit de review. De bron-PDF
      // wordt niet aangepast; opnieuw analyseren kan de detectie herstellen.
      document.querySelectorAll('[data-remove]').forEach(button => button.addEventListener('click', () => {
        syncControls();
        const item = candidateById.get(button.dataset.remove);
        if (!item) return;
        // Niet fysiek uit de review verwijderen: de tombstone voorkomt dat
        // dezelfde automatische detectie na herladen weer terugkomt.
        item.removed = true;
        item.accepted = false;
        const page = result.pages[item.page_index];
        page.candidates = page.candidates.filter(candidate => candidate.id !== item.id);
        page.candidate_count = page.candidates.length;
        renderAll();
      }));

      $('#saveStartReview').addEventListener('click', async () => {
        try {
          const saved = await saveReview();
          $('#startReviewMessage').textContent = `${saved.review.accepted_count} vraagstarts geaccepteerd; ${saved.review.rejected_count} afgewezen. Conceptreview opgeslagen.`;
        } catch (error) { $('#startReviewMessage').textContent = error.message; }
      });
      $('#completeStartReview').addEventListener('click', async () => {
        try {
          const saved = await saveReview();
          if (!saved.review.accepted_count) throw new Error('Er is geen enkele vraagstart geaccepteerd. Controleer eerst de detectie.');
          await api(`/api/exams/${state.examId}/steps/${stepKey}/complete`, {
            method:'POST', headers:{'Content-Type':'application/json'},
            body:JSON.stringify({reviewed:true, reviewed_all_pages:true, accepted_count:saved.review.accepted_count})
          });
          await openWorkspace(state.examId);
        } catch (error) { $('#startReviewMessage').textContent = error.message; }
      });
    };
    renderAll();
  } catch (error) {
    panel.innerHTML = `<h2>Vraagstarts controleren</h2><p class="form-error">${escapeHtml(error.message)}</p>`;
  }
}



/* Stap 3 voor het opgavenboekje gebruikt één doorlopende afbeelding. De docent
   selecteert daarop rechthoekige verticale bereiken en classificeert elk bereik
   als context of vraag. De rechter inspector beheert de koppeling met één of
   meer vraagnummers; de selectiecoördinaten blijven in pixels van de stitchbron. */
async function renderStitchedOpgavenStage(stepKey, startsStepKey, stageLabel, stageTitle) {
  const panel = $('#stagePanel');
  panel.innerHTML = '<p class="muted">Het examen wordt samengevoegd tot één lange afbeelding…</p>';
  try {
    const result = await api(`/api/exams/${state.examId}/stitched-opgaven`);
    let selections = (result.selections || []).map(item => ({...item}));
    let activeIndex = selections.length ? 0 : -1;
    let pendingTop = null;
    let pointerStart = null;
    panel.innerHTML = `
      <p class="eyebrow">${stageLabel}</p><h2>${escapeHtml(stageTitle)}</h2>
      <p class="lead">Het opgavenboekje (vanaf pagina 2) staat hieronder als één doorlopende afbeelding. Selecteer eerst de boven- en daarna de ondergrens van een fragment. Classificeer het fragment rechts en koppel het aan de bijbehorende vra(a)g(en).</p>
      <div class="notice">${result.pages.length} pagina's samengevoegd · pagina 1 overgeslagen · voetteksten en grote buitenmarges waar mogelijk verwijderd. De bron-PDF blijft ongewijzigd.</div>
      <div class="stitched-workspace">
        <section class="stitched-view"><div class="stitched-toolbar"><button class="quiet" id="beginFragment">Nieuw fragment selecteren</button><span id="selectionHint" class="muted">Kies ‘Nieuw fragment selecteren’.</span></div>
          <div class="stitched-image-wrap" id="stitchedImageWrap"><img id="stitchedImage" src="${result.image_url}" alt="Samengevoegd examen"><div id="stitchedOverlay" class="stitched-overlay"></div></div>
        </section>
        <aside class="stitched-inspector"><h3>Fragmenten</h3><div id="stitchedSelectionList"></div><div id="stitchedEditor"><p class="muted">Selecteer een fragment of maak een nieuw fragment aan.</p></div></aside>
      </div>
      <div class="review-actions"><button class="primary" id="saveStitched">Selecties opslaan</button><button class="primary" id="completeStitched">Fragmentcontrole goedkeuren en doorgaan</button></div><p id="stitchedMessage" class="form-error" role="status"></p>`;

    const img = $('#stitchedImage');
    const wrap = $('#stitchedImageWrap');
    const overlay = $('#stitchedOverlay');
    const hint = $('#selectionHint');
    const list = $('#stitchedSelectionList');
    const editor = $('#stitchedEditor');
    const imageY = event => {
      const rect = img.getBoundingClientRect();
      return Math.max(0, Math.min(result.height, (event.clientY - rect.top) * result.height / rect.height));
    };
    const render = () => {
      list.innerHTML = selections.map((item, index) => `<button type="button" class="stitched-list-item ${index===activeIndex?'active':''}" data-select-fragment="${index}"><strong>${item.type==='context'?'Context':'Vraag'} ${index+1}</strong><small>Vragen ${item.question_numbers.join(', ')} · ${Math.round(item.bottom-item.top)} px</small></button>`).join('') || '<p class="muted">Nog geen fragmenten geselecteerd.</p>';
      overlay.innerHTML = selections.map((item,index) => `<div class="stitched-selection ${index===activeIndex?'active':''}" style="top:${item.top/result.height*100}%;height:${(item.bottom-item.top)/result.height*100}%" data-overlay-select="${index}"><span>${item.type==='context'?'Context':'Vraag'} · ${item.question_numbers.join(', ')}</span></div>`).join('') + (pendingTop!==null?`<div class="stitched-pending" style="top:${pendingTop/result.height*100}%"></div>`:'');
      if(activeIndex<0 || !selections[activeIndex]) { editor.innerHTML='<p class="muted">Selecteer een fragment of maak een nieuw fragment aan.</p>'; return; }
      const item=selections[activeIndex];
      editor.innerHTML=`<h3>Geselecteerd fragment</h3><label>Type fragment<select id="fragmentType"><option value="context" ${item.type==='context'?'selected':''}>Context</option><option value="vraag" ${item.type==='vraag'?'selected':''}>Vraag</option></select></label><label>Bij welk(e) vraagnummer(s)?<input id="fragmentQuestions" value="${item.question_numbers.join(', ')}" placeholder="bijvoorbeeld 1, 2, 3"></label><label>Omschrijving (optioneel)<input id="fragmentLabel" value="${escapeHtml(item.label||'')}" placeholder="Korte herkenbare omschrijving"></label><div class="analysis-fields"><label>Bovengrens (px)<input id="fragmentTop" type="number" min="0" max="${result.height}" value="${Math.round(item.top)}"></label><label>Ondergrens (px)<input id="fragmentBottom" type="number" min="1" max="${result.height}" value="${Math.round(item.bottom)}"></label></div><div class="review-actions"><button type="button" class="quiet" id="deleteFragment">Fragment verwijderen</button></div>`;
      $('#fragmentType').addEventListener('change',e=>{item.type=e.target.value;render();});
      $('#fragmentQuestions').addEventListener('change',e=>{const nums=e.target.value.split(',').map(v=>Number(v.trim())).filter(n=>Number.isInteger(n)&&n>0&&n<=60);item.question_numbers=[...new Set(nums)];render();});
      $('#fragmentLabel').addEventListener('change',e=>{item.label=e.target.value;});
      const updateBoundary = () => {
        const top = Number($('#fragmentTop').value), bottom = Number($('#fragmentBottom').value);
        if (Number.isFinite(top) && Number.isFinite(bottom) && top >= 0 && bottom <= result.height && bottom > top) {
          item.top = top; item.bottom = bottom; render();
        }
      };
      $('#fragmentTop').addEventListener('change', updateBoundary);
      $('#fragmentBottom').addEventListener('change', updateBoundary);
      $('#deleteFragment').addEventListener('click',()=>{selections.splice(activeIndex,1);activeIndex=selections.length?Math.min(activeIndex,selections.length-1):-1;render();});
      list.querySelectorAll('[data-select-fragment]').forEach(button=>button.addEventListener('click',()=>{activeIndex=Number(button.dataset.selectFragment);render();}));
      overlay.querySelectorAll('[data-overlay-select]').forEach(el=>el.addEventListener('click',()=>{activeIndex=Number(el.dataset.overlaySelect);render();}));
    };
    $('#beginFragment').addEventListener('click',()=>{pendingTop=null;pointerStart=null;hint.textContent='Klik op de afbeelding bij de bovenrand van het fragment.';wrap.classList.add('selecting');render();});
    img.addEventListener('click',event=>{
      if(!wrap.classList.contains('selecting')) return;
      const y=imageY(event);
      if(pendingTop===null){pendingTop=y;hint.textContent='Klik nu bij de onderrand van hetzelfde fragment.';render();return;}
      const top=Math.min(pendingTop,y),bottom=Math.max(pendingTop,y);
      if(bottom-top<12){hint.textContent='Het fragment is te klein. Kies opnieuw.';pendingTop=null;render();return;}
      selections.push({id:`fragment-${Date.now()}-${selections.length}`,type:'vraag',top,bottom,question_numbers:[],label:''});
      activeIndex=selections.length-1;pendingTop=null;wrap.classList.remove('selecting');hint.textContent='Fragment toegevoegd. Vul rechts type en vraagnummers in.';render();
    });
    $('#saveStitched').addEventListener('click',async()=>{
      try{await api(`/api/exams/${state.examId}/stitched-opgaven/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({selections,reviewed:false})});$('#stitchedMessage').textContent=`${selections.length} fragmentselecties opgeslagen.`;}
      catch(error){$('#stitchedMessage').textContent=error.message;}
    });
    $('#completeStitched').addEventListener('click',async()=>{
      try{
        if(!selections.length)throw new Error('Selecteer eerst de contexten en vragen.');
        if(selections.some(item=>!item.question_numbers.length))throw new Error('Elk fragment moet aan minimaal één vraagnummer gekoppeld zijn.');
        if(!selections.some(item=>item.type==='vraag'))throw new Error('Er moet minimaal één vraagfragment zijn.');
        // Controleer expliciet dat iedere goedgekeurde hoofdvraag ten minste
        // één keer in een vraagselectie voorkomt. Een contextkoppeling alleen
        // is niet voldoende om een vraag als verwerkt te beschouwen.
        const starts=await api(`/api/exams/${state.examId}/question-starts`);
        const nums=(starts.candidates||[]).filter(item=>item.accepted&&!item.removed).map(item=>item.question_number);
        const covered=new Set(selections.filter(item=>item.type==='vraag').flatMap(item=>item.question_numbers));
        const missing=nums.filter(number=>!covered.has(number));
        if(missing.length)throw new Error(`Nog geen vraagfragment geselecteerd voor vraag/vraagvragen: ${missing.join(', ')}.`);
        const saved=await api(`/api/exams/${state.examId}/stitched-opgaven/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({selections,reviewed:true})});
        // De bestaande workflowgate verwacht expliciete goedkeuring per hoofdvraag.
        // Die goedkeuring wordt pas na de integrale selectiecontrole vastgelegd.
        await api(`/api/exams/${state.examId}/document-question-fragments/opgaven/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed_question_numbers:[...new Set(nums)],reviewed_all_questions:true,boundary_overrides:[]})});
        await api(`/api/exams/${state.examId}/steps/${stepKey}/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewed:true,reviewed_all_questions:true,reviewed_question_numbers:[...new Set(nums)].length})});
        await openWorkspace(state.examId);
      }catch(error){$('#stitchedMessage').textContent=error.message;}
    });
    render();
  } catch(error) { panel.innerHTML=`<h2>${escapeHtml(stageTitle)}</h2><p class="form-error">${escapeHtml(error.message)}</p>`; }
}

/* Vraagfragmenten worden pas opgebouwd nadat de hoofdvraagstarts expliciet
   zijn goedgekeurd. Elke vraag kan uit meerdere pagina-afbeeldingen bestaan;
   de docent controleert de complete reeks en keurt die per vraag goed. */
async function renderQuestionFragmentsStage(stepKey, documentType, startsStepKey, stageLabel, stageTitle) {
  if (documentType === 'opgaven') return renderStitchedOpgavenStage(stepKey, startsStepKey, stageLabel, stageTitle);
  const panel = $('#stagePanel');
  panel.innerHTML = '<p class="muted">Vraagfragmenten samenstellen…</p>';
  try {
    const result = await api(`/api/exams/${state.examId}/document-question-fragments/${documentType}`);
    const questions = result.questions;
    const cards = questions.map(question => {
      // Bij een CV wordt het samengestelde plaatje getoond, maar de grenzen
      // worden afgeleid uit de onderliggende originele paginadelen. Bij
      // opgaven en uitwerkbijlage zijn de zichtbare segmenten zelf leidend.
      const sourceSegments = question.source_segments?.length ? question.source_segments : question.segments;
      const firstClip = sourceSegments[0]?.pdf_clip || [0, 0, 0, 0];
      const lastClip = sourceSegments[sourceSegments.length - 1]?.pdf_clip || [0, 0, 0, 0];
      const startY = Number(firstClip[1] || 0).toFixed(2);
      const endY = Number(lastClip[3] || 0).toFixed(2);
      return `
      <article class="fragment-card" data-fragment-card="${question.question_number}">
        <div class="fragment-heading"><h3>Vraag ${question.question_number}</h3><span class="muted">Pagina ${question.first_page}${question.last_page !== question.first_page ? `–${question.last_page}` : ''}</span></div>
        <div class="fragment-images">
          ${question.segments.map((segment, segmentIndex) => {
            // De eerste en laatste pagina krijgen een sleepbare grenslijn.
            // De lijn beweegt op de daadwerkelijke afbeelding; de bijbehorende
            // y-waarde wordt direct omgerekend naar PDF-punten voor opslag.
            const clip = segment.pdf_clip || segment.boundary_info || null;
            const isFirst = segmentIndex === 0 && Boolean(clip);
            const isLast = segmentIndex === question.segments.length - 1 && Boolean(clip);
            const clipData = clip ? escapeHtml(JSON.stringify(clip)) : '';
            return `<figure><figcaption>Originele pagina ${segment.page_number}</figcaption><div class="boundary-image-wrap">
              <img loading="lazy" src="${segment.url}" alt="Fragment van vraag ${question.question_number}, pagina ${segment.page_number}">
              ${isFirst ? `<div class="drag-boundary drag-boundary-start" role="slider" tabindex="0" aria-label="Sleep om de bovengrens van vraag ${question.question_number} aan te passen" data-boundary-drag="start" data-question="${question.question_number}" data-clip="${clipData}"><span>Bovengrens · sleep</span></div>` : ''}
              ${isLast ? `<div class="drag-boundary drag-boundary-end" role="slider" tabindex="0" aria-label="Sleep om de ondergrens van vraag ${question.question_number} aan te passen" data-boundary-drag="end" data-question="${question.question_number}" data-clip="${clipData}"><span>Ondergrens · sleep</span></div>` : ''}
            </div></figure>`;
          }).join('')}
        </div>
        <details class="boundary-editor"><summary>Over de fragmentgrenzen</summary><p class="muted">Sleep de blauwe lijn op de afbeelding om de uitsnede aan te passen. De onderliggende PDF-coördinaten worden automatisch bijgewerkt.</p></details>
        <input type="hidden" data-fragment-start="${question.question_number}" data-initial="${startY}" value="${startY}">
        <input type="hidden" data-fragment-end="${question.question_number}" data-initial="${endY}" value="${endY}">
        <label class="review-warning"><input type="checkbox" data-fragment-reviewed="${question.question_number}" ${question.reviewed ? 'checked' : ''}> Ik heb het volledige fragment van vraag ${question.question_number} gecontroleerd.</label>
      </article>`;
    }).join('');

    panel.innerHTML = `
      <p class="eyebrow">${stageLabel}</p>
      <h2>${escapeHtml(stageTitle)}</h2>
      <p class="lead">De fragmenten zijn afgeleid van de goedgekeurde vraagstarts. Een vraag die over meerdere pagina's loopt, wordt als één vraag met meerdere opeenvolgende pagina-afbeeldingen getoond.</p>
      <div class="notice"><strong>${result.question_count} fragmenten voorgesteld.</strong> Controleer of iedere vraag volledig is opgenomen, inclusief afbeeldingen, tabellen en de onderste tekstregel. De uitsneden zijn afgeleiden; de oorspronkelijke PDF blijft ongewijzigd.</div>
      <div class="review-actions"><button class="quiet" id="adjustQuestionStarts" type="button">Vraagstarts / fragmentgrenzen aanpassen</button></div>
      ${cards}
      <label class="review-warning"><input type="checkbox" id="allFragmentsReviewed"> Ik heb alle vraagfragmenten volledig visueel gecontroleerd.</label>
      <div class="review-actions"><button class="primary" id="saveFragmentReview" type="button">Controle opslaan</button><button class="primary" id="completeFragmentReview" type="button" disabled>Vraagfragmenten goedkeuren en doorgaan</button></div>
      <p id="fragmentReviewMessage" class="form-error" role="status"></p>`;

    $('#adjustQuestionStarts').addEventListener('click', async () => {
      try {
        // Bewaar de bestaande startcorrecties, maar maak deze stap opnieuw
        // actief en verwijder afgeleide goedkeuringen die nu verouderd zijn.
        await api(`/api/exams/${state.examId}/steps/${startsStepKey}/reopen`, {method:'POST'});
        await openWorkspace(state.examId);
      } catch (error) { $('#fragmentReviewMessage').textContent = error.message; }
    });

    // Maak de grenslijnen met muis of touchscreen versleepbaar. De positie
    // wordt relatief aan de zichtbare afbeelding bepaald en daarna omgerekend
    // naar de PDF-puntcoördinaten die de server al gebruikt.
    document.querySelectorAll('[data-boundary-drag]').forEach(handle => {
      const questionNumber = Number(handle.dataset.question);
      const role = handle.dataset.boundaryDrag;
      const clip = JSON.parse(handle.dataset.clip);
      const input = document.querySelector(role === 'start'
        ? `[data-fragment-start="${questionNumber}"]`
        : `[data-fragment-end="${questionNumber}"]`);
      const wrapper = handle.closest('.boundary-image-wrap');
      const updateFromPointer = event => {
        const rect = wrapper.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height));
        let y;
        if (Array.isArray(clip)) {
          // Normale pagina-afbeelding: de hele zichtbare hoogte hoort bij één
          // PDF-uitsnede.
          y = Number(clip[1]) + ratio * (Number(clip[3]) - Number(clip[1]));
        } else if (role === 'start') {
          // Gestitcht CV: de bovengrens hoort bij de eerste bronpagina. Alleen
          // het deel van de samengestelde afbeelding dat die pagina beslaat,
          // wordt naar de y-coördinaat van die bronpagina omgerekend.
          const local = Math.max(0, Math.min(1, ratio * clip.total_height / clip.first_height));
          y = Number(clip.start_clip[1]) + local * (Number(clip.start_clip[3]) - Number(clip.start_clip[1]));
        } else {
          // De ondergrens hoort bij de laatste bronpagina van het CV-fragment.
          const lastPageTop = clip.total_height - clip.last_height;
          const local = Math.max(0, Math.min(1, (ratio * clip.total_height - lastPageTop) / clip.last_height));
          y = Number(clip.end_clip[1]) + local * (Number(clip.end_clip[3]) - Number(clip.end_clip[1]));
        }
        input.value = y.toFixed(2);
        handle.style.top = `${ratio * 100}%`;
        handle.style.bottom = 'auto';
        const card = handle.closest('[data-fragment-card]');
        const check = card.querySelector(`[data-fragment-reviewed="${questionNumber}"]`);
        if (check) check.checked = false;
      };
      handle.addEventListener('pointerdown', event => {
        event.preventDefault();
        handle.setPointerCapture(event.pointerId);
        updateFromPointer(event);
      });
      handle.addEventListener('pointermove', event => {
        if (handle.hasPointerCapture(event.pointerId)) updateFromPointer(event);
      });
      handle.addEventListener('pointerup', event => {
        if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
      });
      handle.addEventListener('keydown', event => {
        if (!['ArrowUp','ArrowDown'].includes(event.key)) return;
        event.preventDefault();
        const delta = event.key === 'ArrowUp' ? -1 : 1;
        input.value = (Number(input.value) + delta).toFixed(2);
        let ratio;
        if (Array.isArray(clip)) {
          const range = Number(clip[3]) - Number(clip[1]);
          ratio = (Number(input.value) - Number(clip[1])) / range;
        } else if (role === 'start') {
          const range = Number(clip.start_clip[3]) - Number(clip.start_clip[1]);
          ratio = ((Number(input.value) - Number(clip.start_clip[1])) / range) * clip.first_height / clip.total_height;
        } else {
          const range = Number(clip.end_clip[3]) - Number(clip.end_clip[1]);
          ratio = (clip.total_height - clip.last_height + ((Number(input.value) - Number(clip.end_clip[1])) / range) * clip.last_height) / clip.total_height;
        }
        handle.style.top = `${Math.max(0,Math.min(100,ratio*100))}%`;
        handle.style.bottom = 'auto';
      });
    });

    const reviewedNumbers = () => [...document.querySelectorAll('[data-fragment-reviewed]:checked')]
      .map(input => Number(input.dataset.fragmentReviewed));
    const allCheckboxes = () => [...document.querySelectorAll('[data-fragment-reviewed]')];
    const refreshComplete = () => {
      $('#completeFragmentReview').disabled = !$('#allFragmentsReviewed').checked
        || allCheckboxes().some(input => !input.checked);
    };
    allCheckboxes().forEach(input => input.addEventListener('change', refreshComplete));
    $('#allFragmentsReviewed').addEventListener('change', refreshComplete);
    refreshComplete();

    const collectBoundaries = () => [...document.querySelectorAll('[data-fragment-card]')].map(card => {
      const number = Number(card.dataset.fragmentCard);
      const start = card.querySelector(`[data-fragment-start="${number}"]`);
      const end = card.querySelector(`[data-fragment-end="${number}"]`);
      return {question_number:number, start_y:Number(start.value), end_y:Number(end.value),
        changed:Math.abs(Number(start.value)-Number(start.dataset.initial))>0.01 || Math.abs(Number(end.value)-Number(end.dataset.initial))>0.01};
    });
    const save = async () => {
      const boundaries = collectBoundaries();
      const changedNumbers = new Set(boundaries.filter(item=>item.changed).map(item=>item.question_number));
      // Een vraag waarvan de uitsnede wijzigt, kan niet met de oude visuele
      // goedkeuring door. Na opnieuw renderen moet die vraag opnieuw worden bekeken.
      for (const number of changedNumbers) {
        const check = document.querySelector(`[data-fragment-reviewed="${number}"]`);
        if (check) check.checked = false;
      }
      const reviewed = reviewedNumbers();
      return {saved:await api(`/api/exams/${state.examId}/document-question-fragments/${documentType}/review`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({reviewed_question_numbers:reviewed,
          reviewed_all_questions:$('#allFragmentsReviewed').checked && changedNumbers.size===0,
          boundary_overrides:boundaries.map(({question_number,start_y,end_y})=>({question_number,start_y,end_y}))})
      }), changedNumbers};
    };
    $('#saveFragmentReview').addEventListener('click', async () => {
      try {
        const {saved,changedNumbers} = await save();
        if (changedNumbers.size) {
          $('#fragmentReviewMessage').textContent = `Grenzen van ${[...changedNumbers].map(n=>`vraag ${n}`).join(', ')} opgeslagen. De nieuwe fragmenten worden opnieuw gerenderd; controleer ze daarna opnieuw.`;
          await openWorkspace(state.examId);
          return;
        }
        $('#fragmentReviewMessage').textContent = `${saved.reviewed_count} van ${saved.expected_count} vraagfragmenten gecontroleerd. Conceptreview opgeslagen.`;
      } catch (error) { $('#fragmentReviewMessage').textContent = error.message; }
    });
    $('#completeFragmentReview').addEventListener('click', async () => {
      try {
        const {saved,changedNumbers} = await save();
        if (changedNumbers.size) {
          $('#fragmentReviewMessage').textContent = 'De gewijzigde grenzen zijn opgeslagen. Controleer eerst de opnieuw gerenderde fragmenten.';
          await openWorkspace(state.examId);
          return;
        }
        if (!saved.complete) throw new Error('Niet alle vraagfragmenten zijn gecontroleerd.');
        await api(`/api/exams/${state.examId}/steps/${stepKey}/complete`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({reviewed:true, reviewed_all_questions:true,
            reviewed_question_numbers:saved.reviewed_count})
        });
        await openWorkspace(state.examId);
      } catch (error) { $('#fragmentReviewMessage').textContent = error.message; }
    });
  } catch (error) {
    panel.innerHTML = `<h2>Vraagfragmenten controleren</h2><p class="form-error">${escapeHtml(error.message)}</p>`;
  }
}

/* De analysefase gebruikt het volledige vraagfragment als visuele bron.
   Tekstlaagherkenning levert alleen voorlopige suggesties voor type, score en
   antwoordopties; elk veld blijft door de docent aanpasbaar en moet per vraag
   expliciet worden gecontroleerd voordat de fase kan worden afgerond. */
async function renderQuestionAnalysisStage() {
  const panel = $('#stagePanel');
  panel.innerHTML = '<p class="muted">Vraagtypen en antwoordopties analyseren…</p>';
  try {
    const result = await api(`/api/exams/${state.examId}/question-analysis`);
    const questionCards = result.questions.map(question => {
      const optionText = question.options.map(option => `${option.letter}. ${option.text}`).join('\n');
      return `
        <article class="analysis-card" data-analysis-card="${question.question_number}">
          <div class="fragment-heading"><h3>Vraag ${question.question_number}</h3><span class="muted">Voorstel: ${escapeHtml(question.question_type)}</span></div>
          <div class="fragment-images">
            ${question.segments.map(segment => `<figure><figcaption>Pagina ${segment.page_number}</figcaption><img loading="lazy" src="${segment.url}" alt="Vraag ${question.question_number}, pagina ${segment.page_number}"></figure>`).join('')}
          </div>
          <div class="analysis-fields">
            <label>Vraagtype
              <select data-analysis-type="${question.question_number}">
                <option value="meerkeuze" ${question.question_type === 'meerkeuze' ? 'selected' : ''}>Meerkeuze</option>
                <option value="gesloten" ${question.question_type === 'gesloten' ? 'selected' : ''}>Gesloten antwoord</option>
                <option value="open" ${question.question_type === 'open' ? 'selected' : ''}>Open vraag</option>
                <option value="onbekend" ${question.question_type === 'onbekend' ? 'selected' : ''}>Nog onbekend</option>
              </select>
            </label>
            <label>Maximumscore (punten)
              <input type="number" min="0" max="20" step="1" value="${question.max_points ?? ''}" placeholder="Nog bepalen" data-analysis-points="${question.question_number}">
            </label>
          </div>
          <label class="analysis-options-label">Antwoordopties (één per regel, bijvoorbeeld A. …)
            <textarea rows="4" data-analysis-options="${question.question_number}">${escapeHtml(optionText)}</textarea>
          </label>
          <p class="analysis-reason">Type: ${escapeHtml(question.type_reason)} Score: ${escapeHtml(question.points_reason)}</p>
          <details class="analysis-text"><summary>Tekstlaag uit dit fragment (hulpmiddel, niet leidend)</summary><pre>${escapeHtml(question.extracted_text || 'Geen selecteerbare tekstlaag aangetroffen. Controleer de afbeelding.')}</pre></details>
          <label class="review-warning"><input type="checkbox" data-analysis-reviewed="${question.question_number}" ${question.reviewed ? 'checked' : ''}> Ik heb vraag ${question.question_number}, het vraagtype, de maximumscore en eventuele antwoordopties visueel gecontroleerd.</label>
        </article>`;
    }).join('');

    panel.innerHTML = `
      <p class="eyebrow">FASE 2 · OPGAVENDOCUMENT</p>
      <h2>Vraagtype, punten en antwoordopties</h2>
      <p class="lead">Per vraag staat het volledige fragment uit de oorspronkelijke PDF. De automatische suggesties zijn hulpmiddelen: controleer de afbeelding en corrigeer het vraagtype, de maximumscore en de antwoordopties waar nodig.</p>
      <div class="notice"><strong>${result.question_count} vragen</strong> klaar voor inhoudelijke controle. Als het puntenaantal niet expliciet uit de vraag blijkt, blijft het veld leeg in plaats van dat er een score wordt gegokt.</div>
      ${questionCards}
      <div class="review-actions"><button class="primary" id="saveQuestionAnalysis" type="button">Controle opslaan</button><button class="primary" id="completeQuestionAnalysis" type="button" disabled>Vraaganalyse goedkeuren en doorgaan</button></div>
      <p id="questionAnalysisMessage" class="form-error" role="status"></p>`;

    const cards = [...document.querySelectorAll('[data-analysis-card]')];
    const reviewedInputs = () => [...document.querySelectorAll('[data-analysis-reviewed]')];
    const refreshComplete = () => {
      $('#completeQuestionAnalysis').disabled = reviewedInputs().length !== result.question_count
        || reviewedInputs().some(input => !input.checked);
    };
    reviewedInputs().forEach(input => input.addEventListener('change', refreshComplete));
    refreshComplete();

    const collect = () => cards.map(card => {
      const number = Number(card.dataset.analysisCard);
      const rawPoints = card.querySelector(`[data-analysis-points="${number}"]`).value.trim();
      const optionsText = card.querySelector(`[data-analysis-options="${number}"]`).value;
      const options = optionsText.split(/\r?\n/).map(line => line.trim()).filter(Boolean).map((line, index) => {
        const match = line.match(/^([A-E])[.)]\s*(.*)$/i);
        return match ? {letter:match[1].toUpperCase(), text:match[2].trim()}
          : {letter:'ABCDE'[index] || 'E', text:line};
      });
      return {
        question_number:number,
        question_type:card.querySelector(`[data-analysis-type="${number}"]`).value,
        max_points:rawPoints === '' ? null : Number(rawPoints),
        options,
        reviewed:card.querySelector(`[data-analysis-reviewed="${number}"]`).checked
      };
    });
    const save = async () => api(`/api/exams/${state.examId}/question-analysis/review`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({questions:collect()})
    });
    $('#saveQuestionAnalysis').addEventListener('click', async () => {
      try {
        const saved = await save();
        $('#questionAnalysisMessage').textContent = `${saved.reviewed_count} van ${result.question_count} vragen gecontroleerd. Conceptreview opgeslagen.`;
      } catch (error) { $('#questionAnalysisMessage').textContent = error.message; }
    });
    $('#completeQuestionAnalysis').addEventListener('click', async () => {
      try {
        const saved = await save();
        if (!saved.complete) throw new Error('Controleer eerst alle vragen.');
        await api(`/api/exams/${state.examId}/steps/opgaven_analyse/complete`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({reviewed:true, reviewed_all_questions:true, reviewed_count:saved.reviewed_count})
        });
        await openWorkspace(state.examId);
      } catch (error) { $('#questionAnalysisMessage').textContent = error.message; }
    });
  } catch (error) {
    panel.innerHTML = `<h2>Vraagtype, punten en antwoordopties</h2><p class="form-error">${escapeHtml(error.message)}</p>`;
  }
}
